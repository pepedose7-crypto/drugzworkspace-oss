// This file will be loaded dynamically or as a module
import { loadPyodide } from "https://esm.sh/pyodide@0.24.1";

let pyodide = null;

export async function runPython(code) {
  if (!pyodide) {
    pyodide = await loadPyodide({
      indexURL: "https://cdn.jsdelivr.net/pyodide/v0.24.1/full/"
    });
  }
  
  try {
    const result = await pyodide.runPythonAsync(code);
    return { success: true, result: String(result) };
  } catch (err) {
    return { success: false, result: err.message };
  }
}
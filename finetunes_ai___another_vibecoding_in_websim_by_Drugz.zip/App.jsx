import { jsxDEV } from "react/jsx-dev-runtime";
import React, { useState, useEffect, useRef, useMemo, useCallback } from "react";
import { createRoot } from "react-dom/client";
import Editor from "@monaco-editor/react";
import {
  Plus,
  Play,
  Save,
  Share2,
  Home,
  LayoutDashboard,
  Terminal,
  Code2,
  Settings,
  User,
  Send,
  Trash2,
  Edit3,
  Eye,
  Search,
  Heart,
  MessageSquare,
  ChevronRight,
  ChevronDown,
  FileCode,
  Folder,
  CheckCircle,
  AlertCircle,
  Loader2,
  Sparkles,
  Cpu,
  Globe,
  Coins,
  Wallet,
  Zap,
  Menu,
  X,
  MoreHorizontal,
  Download,
  History,
  Boxes,
  Box,
  Layers,
  FileJson,
  FileText,
  FileCode2
} from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import DOMPurify from "dompurify";
import { marked } from "marked";
if (typeof window !== "undefined" && window.ResizeObserver) {
  try {
    const OriginalResizeObserver = window.ResizeObserver;
    window.ResizeObserver = function(callback) {
      const wrapped = new OriginalResizeObserver((entries) => {
        try {
          callback(entries);
        } catch (err) {
          console.warn("ResizeObserver callback suppressed error:", err && err.message ? err.message : err);
        }
      });
      return wrapped;
    };
    window.ResizeObserver.prototype = OriginalResizeObserver.prototype;
  } catch (e) {
    console.warn("ResizeObserver wrapper failed:", e);
  }
}
const HF_API_KEY = "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";
const GROQ_API_KEY = "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";
const OPENROUTER_API_KEYS = [
  "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",
  "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",
  "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"
];
let _orKeyIndex = Math.floor(Math.random() * OPENROUTER_API_KEYS.length);
function getOpenRouterKey() {
  const key = OPENROUTER_API_KEYS[_orKeyIndex % OPENROUTER_API_KEYS.length];
  _orKeyIndex = (_orKeyIndex + 1) % OPENROUTER_API_KEYS.length;
  return key;
}
const POLLINATIONS_API_KEY = "sk_pfzbvx7kdvgXN01c1iDh4R7nCRKmDDQo";
const HF_STORAGE_KEY = "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";
const HF_DATASET_REPO = "JustDrugz/Files";
const MODELS = [
  { id: "gpt-oss-120b", name: "GPT-OSS 120B", provider: "OpenRouter", url: "openai/gpt-oss-120b", color: "#00b4ff", multiplier: 1.2, icon: "/64px-ChatGPT-Logo.svg.png", description: "GPT-OSS 120B \u2014 high-capacity general purpose assistant (OpenRouter)." },
  { id: "gpt-5-mini", name: "GPT-5 Mini", provider: "Pollinations", url: "openai/gpt-5-mini", color: "#7c3aed", multiplier: 0.6, icon: "/64px-ChatGPT-Logo.svg.png", description: "GPT-5 Mini \u2014 fast, lightweight conversational coding assistant (Pollinations)." },
  { id: "nvidia-nematron", name: "NVIDIA Llama Nematron", provider: "OpenRouter", url: "nvidia/llama-nematron-70b", color: "#4ade80", multiplier: 1.3, icon: "/nvidia-color.svg", description: "NVIDIA-backed high-precision Nematron model." },
  { id: "glm-4-5-air", name: "GLM-4.5 AIR", provider: "OpenRouter", url: "z-ai/glm-4-5-air", color: "#f97316", multiplier: 1, icon: "/zai (1).svg", description: "GLM-4.5 AIR \u2014 improved multi-modal reasoning." },
  { id: "kimi-k2-instruct", name: "Kimi K2 Instruct", provider: "OpenRouter", url: "moonshotai/kimi-k2-instruct", color: "#6366f1", multiplier: 1.2, icon: "/kimi-color.svg", description: "Ultra-fast logical reasoning and large context support." },
  { id: "qwen3-32b", name: "Qwen 2.5 72B", provider: "OpenRouter", url: "qwen/qwen-2.5-72b-instruct", color: "#14b8a6", multiplier: 0.8, icon: "/qwen-color (1).svg", description: "Optimized for clean code and rapid file generation." },
  { id: "llama-3-70b", name: "Llama 3.1 70B", provider: "OpenRouter", url: "meta-llama/llama-3.1-70b-instruct", color: "#0668E1", multiplier: 0.9, icon: "/metaai-color.svg", description: "High precision for general purpose tasks." },
  { id: "claude-fast", name: "Claude Haiku 4.5", provider: "Pollinations", url: "anthropic/claude-haiku-4.5", color: "#ff6b6b", multiplier: 1, icon: "/claude-color (1).svg", description: "Claude Haiku 4.5 \u2014 creative and concise assistant (served via Pollinations)." }
];
const TEMPLATES = {
  empty: {
    "index.html": `<!DOCTYPE html>
<html>
<head>
  <title>Empty Project</title>
</head>
<body>
  <div id="root"></div>
</body>
</html>`,
    "style.css": `body { margin: 0; background: #000; color: #fff; }`,
    "main.jsx": `// Start coding here`
  },
  helloworld: {
    "index.html": `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8" />
  <title>Hello World</title>
</head>
<body>
  <div id="root"></div>
  <script type="module" src="main.jsx"><\/script>
</body>
</html>`,
    "style.css": `body { margin: 0; font-family: sans-serif; background: #050505; color: white; display: flex; justify-content: center; align-items: center; height: 100vh; }
.card { background: #111; border: 1px solid #222; padding: 2rem; border-radius: 1rem; box-shadow: 0 10px 30px rgba(0,0,0,0.5); text-align: center; }`,
    "main.jsx": `import React from 'react';
import { createRoot } from 'react-dom/client';

const App = () => (
  <div className="card">
    <h1 style={{color: '#6366f1'}}>FineTunes AI</h1>
    <p>React + JSX is active!</p>
    <button 
      style={{padding: '10px 20px', borderRadius: '8px', border: 'none', background: '#6366f1', color: 'white', cursor: 'pointer'}}
      onClick={() => alert('Vibe Coding Active!')}
    >
      Test Interaction
    </button>
  </div>
);

createRoot(document.getElementById('root')).render(<App />);`
  }
};
const room = new WebsimSocket();
async function createAIRequest(projectId, model, prompt, files = null) {
  try {
    const payload = {
      project_id: projectId,
      model: { id: model.id, name: model.name, provider: model.provider, url: model.url },
      prompt: String(prompt || ""),
      files: files || null,
      status: "pending",
      created_by_ai: true,
      created_at: (/* @__PURE__ */ new Date()).toISOString()
    };
    const rec = await room.collection("ai_request").create(payload);
    console.info("AI Request created:", rec.id);
    return rec;
  } catch (err) {
    console.error("Failed to create AI request:", err);
    throw err;
  }
}
function safePrompt(label, defaultValue) {
  try {
    if (typeof window.prompt === "function") {
      const res = window.prompt(label, defaultValue);
      return res === null || res === void 0 ? null : res;
    }
  } catch (e) {
  }
  if (defaultValue) return defaultValue;
  const stamp = (/* @__PURE__ */ new Date()).toISOString().replace(/[:.]/g, "-");
  return `${label.replace(/\s+/g, "_") || "item"}_${stamp}`;
}
function App() {
  const [view, setView] = useState("home");
  const [activeProject, setActiveProject] = useState(null);
  const [activeRepo, setActiveRepo] = useState(null);
  const [projects, setProjects] = useState([]);
  const [repos, setRepos] = useState([]);
  const [homeTab, setHomeTab] = useState("apps");
  const [user, setUser] = useState(null);
  const [credits, setCredits] = useState(20);
  const [searchQuery, setSearchQuery] = useState("");
  const [isSyncing, setIsSyncing] = useState(false);
  const syncCredits = async (currentUser) => {
    if (!currentUser) return;
    setIsSyncing(true);
    try {
      const project = await window.websim.getCurrentProject();
      const response = await fetch(`/api/v1/projects/${project.id}/comments?only_tips=true`);
      const data = await response.json();
      const userTips = data.comments.data.filter((c) => c.comment.author.id === currentUser.id).reduce((acc, c) => acc + (c.comment.card_data?.credits_spent || 0), 0);
      const baseCredits = 20;
      const earnedCredits = userTips * 10;
      const total = baseCredits + earnedCredits;
      setCredits(total);
      localStorage.setItem(`ft_credits_${currentUser.id}`, total.toString());
    } catch (e) {
      console.error("Sync error:", e);
    } finally {
      setIsSyncing(false);
    }
  };
  useEffect(() => {
    const init = async () => {
      try {
        await room.initialize();
        const u = await window.websim.getCurrentUser();
        setUser(u);
        room.collection("project_v2").subscribe(setProjects);
        room.collection("repo_v1").subscribe(setRepos);
        const today = (/* @__PURE__ */ new Date()).toDateString();
        const lastBonus = localStorage.getItem(`ft_daily_bonus_${u?.id}`);
        if (lastBonus !== today) {
          const currentC = Number(localStorage.getItem(`ft_credits_${u?.id}`)) || 20;
          const updated = currentC + 5;
          localStorage.setItem(`ft_credits_${u?.id}`, updated.toString());
          localStorage.setItem(`ft_daily_bonus_${u?.id}`, today);
          setCredits(updated);
        } else {
          await syncCredits(u);
        }
      } catch (err) {
        console.error("Initialization error:", err);
      }
    };
    init();
  }, []);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const handleCreateNew = () => {
    if (credits <= 0) {
      alert("No credits! Please tip the project creator to recharge.");
      return;
    }
    setShowCreateModal(true);
  };
  const finalizeCreate = async (type, name, template) => {
    setShowCreateModal(false);
    if (!name) return;
    if (type === "repo") {
      const newRepo = {
        name,
        description: "Hugging Face Cloud Repository",
        hf_path: `repos/${user?.username}/${name.toLowerCase().replace(/\s+/g, "-")}`,
        published: false,
        views: 0,
        likes: 0,
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        username: user?.username
      };
      const created = await room.collection("repo_v1").create(newRepo);
      setActiveRepo(created);
      setView("repo_explorer");
    } else {
      const initialFiles = template === "helloworld" ? TEMPLATES.helloworld : TEMPLATES.empty;
      const newProject = {
        name,
        description: "A new workspace on FineTunes AI",
        files: initialFiles,
        published: false,
        views: 0,
        likes: 0,
        allowAIEdit: true,
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        username: user?.username
      };
      const created = await room.collection("project_v2").create(newProject);
      setActiveProject(created);
      setView("editor");
    }
  };
  const filteredProjects = projects.filter(
    (p) => (p.published || p.username === user?.username) && (p.name.toLowerCase().includes(searchQuery.toLowerCase()) || p.description.toLowerCase().includes(searchQuery.toLowerCase()))
  );
  return /* @__PURE__ */ jsxDEV("div", { className: "flex h-screen w-screen overflow-hidden bg-[#030303] text-slate-200", children: [
    /* @__PURE__ */ jsxDEV(AnimatePresence, { children: showCreateModal && /* @__PURE__ */ jsxDEV("div", { className: "fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-md p-6", children: /* @__PURE__ */ jsxDEV(
      motion.div,
      {
        initial: { scale: 0.9, opacity: 0 },
        animate: { scale: 1, opacity: 1 },
        exit: { scale: 0.9, opacity: 0 },
        className: "w-full max-w-2xl bg-[#0a0a0c] border border-white/10 rounded-[2.5rem] p-10 shadow-2xl overflow-hidden relative",
        children: [
          /* @__PURE__ */ jsxDEV("div", { className: "absolute top-0 right-0 w-64 h-64 bg-indigo-500/10 blur-[100px] rounded-full -translate-y-1/2 translate-x-1/2" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 267,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("h2", { className: "text-4xl font-black mb-2 text-white", children: "Create New" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 269,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-slate-400 mb-8 font-medium", children: "Choose your environment type to start building." }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 270,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6", children: [
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => {
                  const name = safePrompt("Workspace Name:", "My Project");
                  if (name) finalizeCreate("workspace", name, confirm("Use React Hello World template?") ? "helloworld" : "empty");
                },
                className: "group p-8 rounded-[2rem] bg-indigo-500/5 border border-white/5 hover:border-indigo-500/50 hover:bg-indigo-500/10 transition-all text-left flex flex-col gap-4",
                children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-14 h-14 rounded-2xl bg-indigo-500/20 flex items-center justify-center text-indigo-400 group-hover:scale-110 transition-transform", children: /* @__PURE__ */ jsxDEV(Box, { size: 32 }, void 0, false, {
                    fileName: "<stdin>",
                    lineNumber: 281,
                    columnNumber: 21
                  }, this) }, void 0, false, {
                    fileName: "<stdin>",
                    lineNumber: 280,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold text-white", children: "Workspace" }, void 0, false, {
                      fileName: "<stdin>",
                      lineNumber: 284,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-slate-500 mt-1", children: "High-fidelity IDE with hot-reloading and AI editing." }, void 0, false, {
                      fileName: "<stdin>",
                      lineNumber: 285,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "<stdin>",
                    lineNumber: 283,
                    columnNumber: 19
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "<stdin>",
                lineNumber: 273,
                columnNumber: 17
              },
              this
            ),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: () => {
                  const name = safePrompt("Repository Name:", "my-repo");
                  if (name) finalizeCreate("repo", name);
                },
                className: "group p-8 rounded-[2rem] bg-emerald-500/5 border border-white/5 hover:border-emerald-500/50 hover:bg-emerald-500/10 transition-all text-left flex flex-col gap-4",
                children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "w-14 h-14 rounded-2xl bg-emerald-500/20 flex items-center justify-center text-emerald-400 group-hover:scale-110 transition-transform", children: /* @__PURE__ */ jsxDEV(Boxes, { size: 32 }, void 0, false, {
                    fileName: "<stdin>",
                    lineNumber: 297,
                    columnNumber: 21
                  }, this) }, void 0, false, {
                    fileName: "<stdin>",
                    lineNumber: 296,
                    columnNumber: 19
                  }, this),
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold text-white", children: "Repository" }, void 0, false, {
                      fileName: "<stdin>",
                      lineNumber: 300,
                      columnNumber: 21
                    }, this),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm text-slate-500 mt-1", children: "Hugging Face backed storage for files and datasets." }, void 0, false, {
                      fileName: "<stdin>",
                      lineNumber: 301,
                      columnNumber: 21
                    }, this)
                  ] }, void 0, true, {
                    fileName: "<stdin>",
                    lineNumber: 299,
                    columnNumber: 19
                  }, this)
                ]
              },
              void 0,
              true,
              {
                fileName: "<stdin>",
                lineNumber: 289,
                columnNumber: 17
              },
              this
            )
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 272,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "mt-10 flex justify-end", children: /* @__PURE__ */ jsxDEV("button", { onClick: () => setShowCreateModal(false), className: "px-8 py-3 rounded-xl font-black text-slate-500 hover:text-white transition-colors uppercase tracking-widest text-xs", children: "Cancel" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 307,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 306,
            columnNumber: 15
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "<stdin>",
        lineNumber: 261,
        columnNumber: 13
      },
      this
    ) }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 260,
      columnNumber: 11
    }, this) }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 258,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("nav", { className: "w-16 md:w-20 border-r border-white/5 flex flex-col items-center py-6 gap-8 glass z-50", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "w-11 h-11 accent-gradient rounded-2xl flex items-center justify-center cursor-pointer shadow-xl shadow-indigo-600/20 group", onClick: () => setView("home"), children: /* @__PURE__ */ jsxDEV(Sparkles, { className: "text-white group-hover:rotate-12 transition-transform", size: 24 }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 317,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 316,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-6 flex-grow", children: [
        /* @__PURE__ */ jsxDEV(NavItem, { icon: /* @__PURE__ */ jsxDEV(Home, { size: 22 }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 321,
          columnNumber: 26
        }, this), active: view === "home", onClick: () => setView("home"), label: "Explore" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 321,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(NavItem, { icon: /* @__PURE__ */ jsxDEV(LayoutDashboard, { size: 22 }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 322,
          columnNumber: 26
        }, this), active: view === "dashboard", onClick: () => setView("dashboard"), label: "Workspaces" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 322,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(NavItem, { icon: /* @__PURE__ */ jsxDEV(Code2, { size: 22 }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 323,
          columnNumber: 26
        }, this), active: view === "editor", onClick: () => activeProject ? setView("editor") : handleCreateNew(), label: "IDE" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 323,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 320,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-6 items-center", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col items-center gap-1 cursor-pointer group", title: "Manage credits", children: [
          /* @__PURE__ */ jsxDEV(
            "div",
            {
              className: `p-2 bg-amber-500/10 text-amber-500 rounded-lg group-hover:bg-amber-500/20 transition-all ${isSyncing ? "animate-spin" : ""}`,
              onClick: async () => {
                await syncCredits(user);
              },
              children: /* @__PURE__ */ jsxDEV(Coins, { size: 18 }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 332,
                columnNumber: 15
              }, this)
            },
            void 0,
            false,
            {
              fileName: "<stdin>",
              lineNumber: 328,
              columnNumber: 13
            },
            this
          ),
          /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-bold", children: credits.toFixed(1) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 334,
            columnNumber: 13
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 327,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            title: "Top-up FT from Websim credits",
            onClick: async () => {
              try {
                const current = await window.websim.getCurrentUser();
                const websimAmountStr = safePrompt("Enter Websim credits to convert to FT (1 Websim -> 10 FT):", "1");
                const websimAmount = Number(websimAmountStr);
                if (!websimAmount || websimAmount <= 0) return alert("Invalid amount.");
                if (!confirm(`Convert ${websimAmount} Websim credits to ${websimAmount * 10} FT credits?`)) return;
                const added = websimAmount * 10;
                const newFT = +(credits + added).toFixed(3);
                setCredits(newFT);
                try {
                  localStorage.setItem(`ft_credits_${current?.id}`, newFT.toString());
                } catch (_) {
                }
                setConsoleLogs((prev) => [...prev, { type: "success", content: `Converted ${websimAmount} Websim credits -> ${added} FT credits.`, timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
              } catch (e) {
                console.error("Top-up failed:", e);
                alert("Top-up failed. Check console for details.");
              }
            },
            className: "mt-1 p-1.5 bg-white/3 rounded-lg text-[10px] font-bold text-amber-300 hover:bg-white/5",
            children: "Top-up FT"
          },
          void 0,
          false,
          {
            fileName: "<stdin>",
            lineNumber: 337,
            columnNumber: 11
          },
          this
        ),
        user && /* @__PURE__ */ jsxDEV(
          "img",
          {
            src: `https://images.websim.com/avatar/${user.username}`,
            className: "w-9 h-9 rounded-full border border-white/10 hover:border-indigo-500 transition-all cursor-pointer shadow-lg",
            alt: "User"
          },
          void 0,
          false,
          {
            fileName: "<stdin>",
            lineNumber: 361,
            columnNumber: 13
          },
          this
        )
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 326,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 315,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("main", { className: "flex-grow relative overflow-hidden bg-[radial-gradient(circle_at_top_right,_#111,_#030303)]", children: /* @__PURE__ */ jsxDEV(AnimatePresence, { mode: "wait", children: [
      view === "home" && /* @__PURE__ */ jsxDEV(motion.div, { initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 }, className: "h-full overflow-y-auto pb-20", children: [
        /* @__PURE__ */ jsxDEV("section", { className: "relative py-24 px-10 overflow-hidden bg-gradient-to-br from-indigo-900/20 via-black to-pink-900/10 border-b border-white/5", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "max-w-6xl mx-auto relative z-10", children: /* @__PURE__ */ jsxDEV(motion.div, { initial: { y: 20, opacity: 0 }, animate: { y: 0, opacity: 1 }, transition: { delay: 0.1 }, children: [
            /* @__PURE__ */ jsxDEV("h1", { className: "text-7xl font-black text-white mb-6 tracking-tight leading-none", children: [
              "Elevate Your ",
              /* @__PURE__ */ jsxDEV("span", { className: "accent-gradient bg-clip-text text-transparent", children: "Vibe" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 378,
                columnNumber: 36
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 377,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("p", { className: "text-slate-400 text-xl max-w-2xl font-medium leading-relaxed mb-10", children: "Explore a community of high-fidelity AI-generated workspaces. Fork, build, and deploy with professional-grade models like GPT-OSS 120B and DeepSeek V3." }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 380,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-4", children: [
              /* @__PURE__ */ jsxDEV("button", { onClick: handleCreateNew, className: "accent-gradient px-10 py-4 rounded-2xl font-black text-white shadow-2xl shadow-indigo-500/40 hover:scale-105 active:scale-95 transition-all flex items-center gap-3", children: [
                /* @__PURE__ */ jsxDEV(Plus, { size: 24 }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 385,
                  columnNumber: 25
                }, this),
                " Start Coding Now"
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 384,
                columnNumber: 23
              }, this),
              /* @__PURE__ */ jsxDEV("div", { className: "relative w-full md:w-96", children: [
                /* @__PURE__ */ jsxDEV(Search, { className: "absolute left-5 top-1/2 -translate-y-1/2 text-slate-500", size: 20 }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 388,
                  columnNumber: 25
                }, this),
                /* @__PURE__ */ jsxDEV(
                  "input",
                  {
                    type: "text",
                    placeholder: "Search innovations...",
                    value: searchQuery,
                    onChange: (e) => setSearchQuery(e.target.value),
                    className: "w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-14 pr-6 outline-none focus:border-indigo-500 focus:bg-white/10 transition-all backdrop-blur-sm"
                  },
                  void 0,
                  false,
                  {
                    fileName: "<stdin>",
                    lineNumber: 389,
                    columnNumber: 25
                  },
                  this
                )
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 387,
                columnNumber: 23
              }, this)
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 383,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 376,
            columnNumber: 19
          }, this) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 375,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "absolute top-0 right-0 w-[600px] h-[600px] bg-indigo-500/10 blur-[120px] rounded-full -translate-y-1/2 translate-x-1/2" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 401,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "absolute bottom-0 left-0 w-[400px] h-[400px] bg-pink-500/10 blur-[100px] rounded-full translate-y-1/2 -translate-x-1/2" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 402,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 374,
          columnNumber: 15
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "max-w-6xl mx-auto px-10 mt-16 pb-24", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex border-b border-white/5 mb-10 overflow-x-auto", children: [
            /* @__PURE__ */ jsxDEV("button", { onClick: () => setHomeTab("apps"), className: `px-8 py-4 font-black text-xs uppercase tracking-[0.2em] transition-all whitespace-nowrap ${homeTab === "apps" ? "text-indigo-400 border-b-2 border-indigo-500 bg-indigo-500/5" : "text-slate-500 hover:text-slate-300"}`, children: "Published Apps" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 407,
              columnNumber: 19
            }, this),
            /* @__PURE__ */ jsxDEV("button", { onClick: () => setHomeTab("repos"), className: `px-8 py-4 font-black text-xs uppercase tracking-[0.2em] transition-all whitespace-nowrap ${homeTab === "repos" ? "text-emerald-400 border-b-2 border-emerald-500 bg-emerald-500/5" : "text-slate-500 hover:text-slate-300"}`, children: "Public Repositories" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 408,
              columnNumber: 19
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 406,
            columnNumber: 17
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8", children: [
            homeTab === "apps" ? filteredProjects.filter((p) => p.published).map((proj) => /* @__PURE__ */ jsxDEV(ProjectCard, { project: proj, user, onClick: () => {
              setActiveProject(proj);
              setView("editor");
            } }, proj.id, false, {
              fileName: "<stdin>",
              lineNumber: 414,
              columnNumber: 23
            }, this)) : repos.filter((r) => r.published).map((repo) => /* @__PURE__ */ jsxDEV(RepoCard, { repo, user, onClick: () => {
              setActiveRepo(repo);
              setView("repo_explorer");
            } }, repo.id, false, {
              fileName: "<stdin>",
              lineNumber: 418,
              columnNumber: 23
            }, this)),
            (homeTab === "apps" ? filteredProjects.filter((p) => p.published) : repos.filter((r) => r.published)).length === 0 && /* @__PURE__ */ jsxDEV("div", { className: "col-span-full py-20 text-center border-2 border-dashed border-white/10 rounded-3xl text-slate-600", children: "Nothing has been published here yet." }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 422,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 411,
            columnNumber: 17
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 405,
          columnNumber: 15
        }, this)
      ] }, "home", true, {
        fileName: "<stdin>",
        lineNumber: 373,
        columnNumber: 13
      }, this),
      view === "dashboard" && /* @__PURE__ */ jsxDEV(motion.div, { initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 }, className: "h-full overflow-y-auto p-10 bg-[#020202]", children: /* @__PURE__ */ jsxDEV("div", { className: "max-w-7xl mx-auto", children: [
        /* @__PURE__ */ jsxDEV("header", { className: "flex flex-col md:flex-row justify-between items-start md:items-end mb-12 gap-6", children: [
          /* @__PURE__ */ jsxDEV("div", { children: [
            /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3 text-indigo-400 font-black uppercase tracking-[0.2em] text-xs mb-3", children: [
              /* @__PURE__ */ jsxDEV(LayoutDashboard, { size: 16 }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 437,
                columnNumber: 23
              }, this),
              " Console / Dashboard"
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 436,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ jsxDEV("h1", { className: "text-5xl font-black text-white", children: "Project Management" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 439,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 435,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4", children: /* @__PURE__ */ jsxDEV("button", { onClick: handleCreateNew, className: "px-6 py-3 bg-white text-black font-black rounded-xl hover:bg-slate-200 transition-all flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV(Plus, { size: 18 }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 443,
              columnNumber: 23
            }, this),
            " Create New"
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 442,
            columnNumber: 21
          }, this) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 441,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 434,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-4 gap-6 mb-16", children: [
          /* @__PURE__ */ jsxDEV(StatCard, { label: "Workspaces", value: projects.filter((p) => p.username === user?.username).length, icon: /* @__PURE__ */ jsxDEV(Box, {}, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 449,
            columnNumber: 121
          }, this), color: "indigo" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 449,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(StatCard, { label: "Engagement", value: `${projects.filter((p) => p.username === user?.username).reduce((acc, p) => acc + (p.views || 0), 0)} Views`, icon: /* @__PURE__ */ jsxDEV(Eye, {}, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 450,
            columnNumber: 169
          }, this), color: "purple" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 450,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(StatCard, { label: "Community Love", value: projects.filter((p) => p.username === user?.username).reduce((acc, p) => acc + (p.likes || 0), 0), icon: /* @__PURE__ */ jsxDEV(Heart, {}, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 451,
            columnNumber: 162
          }, this), color: "pink" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 451,
            columnNumber: 19
          }, this),
          /* @__PURE__ */ jsxDEV(StatCard, { label: "Resource Power", value: `${credits.toFixed(1)} FT`, icon: /* @__PURE__ */ jsxDEV(Zap, {}, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 452,
            columnNumber: 93
          }, this), color: "amber" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 452,
            columnNumber: 19
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 448,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mb-8", children: /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold text-white flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV(Layers, { size: 20, className: "text-slate-500" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 457,
            columnNumber: 21
          }, this),
          " Workspace Assets"
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 456,
          columnNumber: 19
        }, this) }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 455,
          columnNumber: 17
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16", children: [
          projects.filter((p) => p.username === user?.username).map((proj) => /* @__PURE__ */ jsxDEV(ProjectCard, { project: proj, user, isOwner: true, onClick: () => {
            setActiveProject(proj);
            setView("editor");
          } }, proj.id, false, {
            fileName: "<stdin>",
            lineNumber: 463,
            columnNumber: 21
          }, this)),
          repos.filter((r) => r.username === user?.username).map((repo) => /* @__PURE__ */ jsxDEV(RepoCard, { repo, user, onClick: () => {
            setActiveRepo(repo);
            setView("repo_explorer");
          } }, repo.id, false, {
            fileName: "<stdin>",
            lineNumber: 466,
            columnNumber: 21
          }, this)),
          /* @__PURE__ */ jsxDEV(
            motion.div,
            {
              whileHover: { scale: 0.98 },
              onClick: handleCreateNew,
              className: "border-2 border-dashed border-white/5 rounded-3xl p-10 flex flex-col items-center justify-center gap-4 hover:bg-white/5 hover:border-white/10 cursor-pointer transition-all group",
              children: [
                /* @__PURE__ */ jsxDEV("div", { className: "w-16 h-16 rounded-full bg-white/5 flex items-center justify-center text-slate-700 group-hover:text-indigo-400 transition-colors", children: /* @__PURE__ */ jsxDEV(Plus, { size: 32 }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 474,
                  columnNumber: 23
                }, this) }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 473,
                  columnNumber: 21
                }, this),
                /* @__PURE__ */ jsxDEV("span", { className: "text-slate-500 font-bold group-hover:text-slate-300", children: "Spin up new environment" }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 476,
                  columnNumber: 21
                }, this)
              ]
            },
            void 0,
            true,
            {
              fileName: "<stdin>",
              lineNumber: 468,
              columnNumber: 19
            },
            this
          )
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 461,
          columnNumber: 17
        }, this)
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 433,
        columnNumber: 15
      }, this) }, "dashboard", false, {
        fileName: "<stdin>",
        lineNumber: 432,
        columnNumber: 13
      }, this),
      view === "editor" && /* @__PURE__ */ jsxDEV(
        EditorView,
        {
          project: activeProject,
          onSave: async (p) => {
            if (!p) return;
            if (p.id) {
              try {
                const updated = await room.collection("project_v2").update(p.id, p).catch(() => null);
                setActiveProject(updated || p);
              } catch (e) {
                console.error(e);
              }
            } else {
              try {
                const created = await room.collection("project_v2").create(p);
                setActiveProject(created);
              } catch (e) {
                console.error(e);
              }
            }
          },
          user,
          credits,
          setCredits: (c) => {
            setCredits(c);
            localStorage.setItem(`ft_credits_${user?.id}`, c.toString());
          }
        },
        void 0,
        false,
        {
          fileName: "<stdin>",
          lineNumber: 484,
          columnNumber: 13
        },
        this
      ),
      view === "repo_explorer" && activeRepo && /* @__PURE__ */ jsxDEV(
        RepoExplorer,
        {
          repo: activeRepo,
          user,
          onBack: () => setView("dashboard")
        },
        void 0,
        false,
        {
          fileName: "<stdin>",
          lineNumber: 517,
          columnNumber: 13
        },
        this
      )
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 371,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 370,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "<stdin>",
    lineNumber: 257,
    columnNumber: 5
  }, this);
}
function NavItem({ icon, active, onClick, label }) {
  return /* @__PURE__ */ jsxDEV("div", { className: "group relative flex items-center justify-center", children: [
    /* @__PURE__ */ jsxDEV(
      "button",
      {
        onClick,
        className: `p-3.5 rounded-2xl transition-all duration-300 ${active ? "bg-indigo-500/15 text-indigo-400" : "text-slate-500 hover:text-slate-200 hover:bg-white/5"}`,
        children: icon
      },
      void 0,
      false,
      {
        fileName: "<stdin>",
        lineNumber: 532,
        columnNumber: 7
      },
      this
    ),
    /* @__PURE__ */ jsxDEV("span", { className: "absolute left-20 bg-slate-900 border border-white/10 text-white text-[10px] font-bold uppercase tracking-tighter px-2 py-1 rounded-md opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity whitespace-nowrap z-[100]", children: label }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 538,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "<stdin>",
    lineNumber: 531,
    columnNumber: 5
  }, this);
}
function FileIcon({ filename, size = 16, className = "" }) {
  const ext = filename.split(".").pop()?.toLowerCase();
  switch (ext) {
    case "html":
      return /* @__PURE__ */ jsxDEV(FileCode, { size, className: `${className} text-orange-500` }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 548,
        columnNumber: 25
      }, this);
    case "css":
      return /* @__PURE__ */ jsxDEV(Layers, { size, className: `${className} text-blue-400` }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 549,
        columnNumber: 24
      }, this);
    case "js":
    case "jsx":
    case "ts":
    case "tsx":
      return /* @__PURE__ */ jsxDEV(Code2, { size, className: `${className} text-yellow-400` }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 550,
        columnNumber: 58
      }, this);
    case "py":
      return /* @__PURE__ */ jsxDEV(Box, { size, className: `${className} text-blue-500` }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 551,
        columnNumber: 23
      }, this);
    case "json":
      return /* @__PURE__ */ jsxDEV(FileJson, { size, className: `${className} text-amber-500` }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 552,
        columnNumber: 25
      }, this);
    case "md":
      return /* @__PURE__ */ jsxDEV(FileText, { size, className: `${className} text-slate-400` }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 553,
        columnNumber: 23
      }, this);
    default:
      return /* @__PURE__ */ jsxDEV(FileCode2, { size, className: `${className} text-slate-500` }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 554,
        columnNumber: 21
      }, this);
  }
}
function ProjectCard({ project, onClick, onPublicView, user }) {
  const handleFork = async (e, openAfter = false) => {
    if (e && e.stopPropagation) e.stopPropagation();
    try {
      const forkName = `${project.name} \u2014 fork`;
      const newProject = {
        name: forkName,
        description: project.description ? `${project.description} (forked)` : `Fork of ${project.name}`,
        files: project.files || {},
        published: false,
        views: 0,
        likes: 0,
        allowAIEdit: project.allowAIEdit ?? true,
        createdAt: (/* @__PURE__ */ new Date()).toISOString()
      };
      const created = await room.collection("project_v2").create(newProject);
      setConsoleLogs((prev) => [...prev, { type: "success", content: `Fork created: ${created.name}`, timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
      if (openAfter && typeof onClick === "function") {
        onClick(created);
      } else {
        alert(`Fork created: ${created.name}`);
      }
    } catch (err) {
      console.error("Fork failed:", err);
      alert("Failed to fork workspace. See console for details.");
    }
  };
  const isOwner = user && project && user.username === project.username;
  return /* @__PURE__ */ jsxDEV(
    motion.div,
    {
      whileHover: { y: -8, scale: 1.02 },
      className: "glass p-6 rounded-3xl transition-all border border-white/5 flex flex-col gap-5 group",
      children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-start", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "w-14 h-14 rounded-2xl bg-indigo-500/10 flex items-center justify-center text-indigo-500 group-hover:bg-indigo-500 group-hover:text-white transition-all", children: /* @__PURE__ */ jsxDEV(Code2, { size: 28 }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 597,
            columnNumber: 11
          }, this) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 596,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [
            /* @__PURE__ */ jsxDEV("button", { onClick: (e) => {
              e.stopPropagation();
              onClick && onClick();
            }, className: "p-2 bg-white/5 rounded-xl hover:text-pink-500 transition-colors", title: "Open in editor", children: /* @__PURE__ */ jsxDEV(Code2, { size: 16 }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 601,
              columnNumber: 14
            }, this) }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 600,
              columnNumber: 12
            }, this),
            /* @__PURE__ */ jsxDEV("button", { onClick: (e) => {
              e.stopPropagation();
              onPublicView && onPublicView(project);
            }, className: "p-2 bg-white/5 rounded-xl hover:text-indigo-400 transition-colors", title: "Open Public Preview", children: /* @__PURE__ */ jsxDEV(Globe, { size: 16 }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 604,
              columnNumber: 14
            }, this) }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 603,
              columnNumber: 12
            }, this),
            !isOwner && /* @__PURE__ */ jsxDEV("button", { onClick: handleFork, className: "p-2 bg-white/5 rounded-xl hover:text-green-400 transition-colors", title: "Fork workspace", children: /* @__PURE__ */ jsxDEV(Save, { size: 16 }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 608,
              columnNumber: 16
            }, this) }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 607,
              columnNumber: 14
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 599,
            columnNumber: 9
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 595,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("div", { onClick: () => {
          const isOwner2 = user && project && user.username === project.username;
          if (isOwner2) {
            onClick && onClick(project);
          } else {
            handleFork(null, true);
          }
        }, className: "cursor-pointer", children: [
          /* @__PURE__ */ jsxDEV("h3", { className: "text-xl font-bold text-white mb-2 truncate", children: project.name }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 623,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("p", { className: "text-slate-400 text-sm line-clamp-2 font-medium", children: project.description }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 624,
            columnNumber: 9
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 613,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between mt-auto pt-5 border-t border-white/5", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2.5", children: [
            /* @__PURE__ */ jsxDEV("img", { src: `https://images.websim.com/avatar/${project.username}`, className: "w-7 h-7 rounded-full ring-2 ring-white/5" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 628,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-bold text-slate-300", children: [
              "@",
              project.username
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 629,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 627,
            columnNumber: 9
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4 text-slate-500 text-[11px] font-bold", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-1.5", children: [
              /* @__PURE__ */ jsxDEV(Eye, { size: 14 }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 632,
                columnNumber: 55
              }, this),
              " ",
              project.views || 0
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 632,
              columnNumber: 11
            }, this),
            /* @__PURE__ */ jsxDEV("span", { className: "flex items-center gap-1.5", children: [
              /* @__PURE__ */ jsxDEV(History, { size: 14 }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 633,
                columnNumber: 55
              }, this),
              " ",
              Object.keys(project.files || {}).length,
              "F"
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 633,
              columnNumber: 11
            }, this)
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 631,
            columnNumber: 9
          }, this)
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 626,
          columnNumber: 7
        }, this)
      ]
    },
    void 0,
    true,
    {
      fileName: "<stdin>",
      lineNumber: 591,
      columnNumber: 5
    },
    this
  );
}
function StatCard({ label, value, icon, color }) {
  const colors = {
    indigo: "text-indigo-400 bg-indigo-400/10",
    purple: "text-purple-400 bg-purple-400/10",
    pink: "text-pink-400 bg-pink-400/10",
    amber: "text-amber-400 bg-amber-400/10"
  };
  return /* @__PURE__ */ jsxDEV("div", { className: "glass p-7 rounded-3xl border border-white/5", children: [
    /* @__PURE__ */ jsxDEV("div", { className: `p-4 w-fit rounded-2xl mb-6 ${colors[color]}`, children: React.cloneElement(icon, { size: 24 }) }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 649,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("p", { className: "text-slate-400 text-xs font-bold uppercase tracking-widest mb-2", children: label }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 652,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("h3", { className: "text-3xl font-black text-white", children: value }, void 0, false, {
      fileName: "<stdin>",
      lineNumber: 653,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "<stdin>",
    lineNumber: 648,
    columnNumber: 5
  }, this);
}
const EditorView = ({ project, onSave, user, credits, setCredits }) => {
  const [files, setFiles] = useState(project?.files || {});
  const [openFiles, setOpenFiles] = useState(() => Object.keys(project?.files || {})?.slice(0, 1) || ["index.html"]);
  const [activeFile, setActiveFile] = useState(() => Object.keys(project?.files || {})[0] || "index.html");
  const [selectedModel, setSelectedModel] = useState(() => MODELS.find((m) => m.id === "nvidia-nematron") || MODELS[0]);
  const [prompt, setPrompt] = useState("");
  const [isGenerating, setIsGenerating] = useState(false);
  const [consoleLogs, setConsoleLogs2] = useState([]);
  const [previewKey, setPreviewKey] = useState(0);
  const [showConsole, setShowConsole] = useState(false);
  const [showChat, setShowChat] = useState(true);
  const [chatPanelWidth, setChatPanelWidth] = useState(480);
  const [aiMode, setAiMode] = useState("code");
  const [showModelPicker, setShowModelPicker] = useState(false);
  const [chatHistory, setChatHistory] = useState([]);
  const [terminalInput, setTerminalInput] = useState("");
  const [showPublishOptions, setShowPublishOptions] = useState(false);
  const [allowAIEdit, setAllowAIEdit] = useState(project?.allowAIEdit ?? true);
  const [allowAIRead, setAllowAIRead] = useState(project?.allowAIRead ?? true);
  const [pendingPatch, setPendingPatch] = useState(null);
  const [contextFiles, setContextFiles] = useState([]);
  const [contextImages, setContextImages] = useState([]);
  const [activeTab, setActiveTab] = useState("refining");
  const iframeRef = useRef(null);
  const chatEndRef = useRef(null);
  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };
  useEffect(() => {
    if (activeTab === "refining") scrollToBottom();
  }, [chatHistory, activeTab]);
  const handleMonacoMount = (editor, monaco) => {
    monaco.editor.defineTheme("ft-vibe-dark", {
      base: "vs-dark",
      inherit: true,
      rules: [
        { token: "comment", foreground: "6272a4", fontStyle: "italic" },
        { token: "keyword", foreground: "ff79c6" },
        { token: "string", foreground: "f1fa8c" },
        { token: "number", foreground: "bd93f9" }
      ],
      colors: {
        "editor.background": "#080808",
        "editor.foreground": "#f8f8f2",
        "editorCursor.foreground": "#aeafad",
        "editor.lineHighlightBackground": "#ffffff0a",
        "editorLineNumber.foreground": "#44475a",
        "editor.selectionBackground": "#44475a",
        "editor.inactiveSelectionBackground": "#44475a"
      }
    });
    monaco.editor.setTheme("ft-vibe-dark");
  };
  const applyPendingPatchNow = async (patch) => {
    if (!patch || !patch.files) return;
    const proceed = confirm(`Apply AI patch with ${Object.keys(patch.files).length} file(s)? This will modify your workspace.`);
    if (!proceed) return;
    setFiles((prevFiles) => {
      const merged = { ...prevFiles, ...patch.files };
      onSave({ ...project || {}, files: merged, allowAIEdit });
      return merged;
    });
    setConsoleLogs2((prev) => [...prev, { type: "success", content: `Applied AI patch (${Object.keys(patch.files).join(", ")})`, timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
    setChatHistory((prev) => [...prev, { role: "assistant", content: `Applied AI patch: ${Object.keys(patch.files).join(", ")}`, filesChanged: Object.keys(patch.files), timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
    setPendingPatch(null);
  };
  useEffect(() => {
    if (project && project.files) {
      setFiles(project.files);
      const first = Object.keys(project.files)[0] || "index.html";
      setOpenFiles((prev) => {
        const existing = prev.filter((f) => project.files[f] !== void 0);
        if (existing.length === 0) return [first];
        return existing;
      });
      setActiveFile((prev) => {
        if (prev && project.files[prev] !== void 0) return prev;
        return first;
      });
    } else {
      setFiles({});
      setOpenFiles(["index.html"]);
      setActiveFile("index.html");
    }
  }, [project]);
  useEffect(() => {
    setAllowAIEdit(project?.allowAIEdit ?? true);
    setAllowAIRead(project?.allowAIRead ?? true);
  }, [project]);
  const activeContent = files[activeFile] || "";
  const updateFileContent = (newContent, filename = null) => {
    const target = filename || activeFile;
    const updatedFiles = { ...files, [target]: newContent };
    setFiles(updatedFiles);
    const updatedProject = { ...project || {}, files: updatedFiles, allowAIEdit };
    onSave(updatedProject);
  };
  const handleRun = useCallback(() => {
    setPreviewKey((prev) => prev + 1);
    setConsoleLogs2((prev) => [...prev, { type: "info", content: "Manual re-run...", timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
  }, []);
  const [currentVersion, setCurrentVersion] = useState(project?.version || 1);
  const [projectVersions, setProjectVersions] = useState(project?.history || []);
  const saveVersion = async () => {
    const nextVersion = (project?.version || 1) + 1;
    const snapshot = {
      version: nextVersion,
      files: { ...files },
      createdAt: (/* @__PURE__ */ new Date()).toISOString(),
      label: `Version ${nextVersion}`
    };
    const updatedHistory = [...project?.history || [], snapshot];
    const updatedProject = {
      ...project || {},
      version: nextVersion,
      files,
      history: updatedHistory
    };
    onSave(updatedProject);
    setCurrentVersion(nextVersion);
    setProjectVersions(updatedHistory);
    setConsoleLogs2((prev) => [...prev, { type: "success", content: `Created snapshot: V${nextVersion}`, timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
  };
  const loadVersion = (v) => {
    if (!v) return;
    const versionData = projectVersions.find((pv) => pv.version === v);
    if (versionData) {
      setFiles(versionData.files);
      setCurrentVersion(v);
      setConsoleLogs2((prev) => [...prev, { type: "info", content: `Restored workspace to V${v}`, timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
    }
  };
  const executeJS = () => {
    if (!terminalInput.trim()) return;
    const cmd = terminalInput.trim();
    if (cmd.startsWith("fine")) {
      const parts = cmd.split(/\s+/);
      const sub = parts[1] || "";
      const arg = parts.slice(2).join(" ");
      const allFiles = Object.keys(files).sort();
      const folders = {};
      allFiles.forEach((f) => {
        const parts2 = f.split("/");
        if (parts2.length > 1) {
          const folder = parts2.slice(0, parts2.length - 1).join("/");
          folders[folder] = folders[folder] || [];
          folders[folder].push(f);
        } else {
          folders[".root"] = folders[".root"] || [];
          folders[".root"].push(f);
        }
      });
      if (sub === "-r") {
        setConsoleLogs2((prev) => [...prev, { type: "info", content: `Workspace files:
${allFiles.join("\n")}`, timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
      } else if (sub === "-k") {
        const lines = Object.entries(folders).map(([folder, items]) => `${folder}:
  ${items.join("\n  ")}`);
        setConsoleLogs2((prev) => [...prev, { type: "info", content: `Workspace tree:
${lines.join("\n\n")}`, timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
      } else if (sub === "-a") {
        if (!arg) {
          const summary = allFiles.map((f) => {
            const txt = String(files[f] || "");
            const preview = txt.length > 300 ? txt.slice(0, 300).replace(/\n/g, " ") + "..." : txt.replace(/\n/g, " ");
            return `${f} \u2014 ${preview}`;
          }).join("\n\n");
          setConsoleLogs2((prev) => [...prev, { type: "info", content: `All files (preview):
${summary}`, timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
        } else {
          const target = arg;
          if (!files[target]) {
            setConsoleLogs2((prev) => [...prev, { type: "error", content: `File not found: ${target}`, timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
          } else {
            setConsoleLogs2((prev) => [...prev, { type: "info", content: `--- ${target} ---
${files[target]}`, timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
          }
        }
      } else {
        setConsoleLogs2((prev) => [...prev, { type: "info", content: `fine usage:
  fine -r      -> list files
  fine -k      -> list folders and files
  fine -a NAME -> show file content (omit NAME to preview all)`, timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
      }
      setTerminalInput("");
      return;
    }
    try {
      iframeRef.current.contentWindow.postMessage({ type: "exec", code: terminalInput }, "*");
      setConsoleLogs2((prev) => [...prev, { type: "info", content: `> ${terminalInput}`, timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
      setTerminalInput("");
    } catch (e) {
      setConsoleLogs2((prev) => [...prev, { type: "error", content: e.message, timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
    }
  };
  const handleModelAction = async () => {
    if (!prompt.trim() || isGenerating) return;
    if (aiMode === "code" && !allowAIEdit) {
      try {
        const requestRec = await createAIRequest(project?.id || null, selectedModel, prompt, null);
        setConsoleLogs2((prev) => [...prev, { type: "info", content: `AI requested edits (pending review): ${requestRec.id}`, timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
        setChatHistory((prev) => [...prev, { role: "assistant", content: `I've prepared an edit request for the workspace. The owner can review and apply these changes from the Requests panel. Request ID: ${requestRec.id}`, filesChanged: null, timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
      } catch (err) {
        setConsoleLogs2((prev) => [...prev, { type: "error", content: `Failed to create AI request: ${err.message}`, timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
        alert("AI edits are disabled and creating a request failed. Check console for details.");
      }
      return;
    }
    setIsGenerating(true);
    const newMessage = { role: "user", content: prompt, timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() };
    setChatHistory((prev) => [...prev, newMessage]);
    setConsoleLogs2((prev) => [...prev, { type: "info", content: `Processing ${aiMode === "ask" ? "inquiry" : "edits"} with ${selectedModel.name}...`, timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
    try {
      const fullPrompt = prompt;
      let response = await callAI(
        selectedModel,
        fullPrompt,
        files,
        activeFile,
        allowAIRead,
        aiMode,
        contextImages
      );
      setContextFiles([]);
      setContextImages([]);
      const stripFences = (text) => {
        if (!text || typeof text !== "string") return text;
        let t = text.trim();
        t = t.replace(/^\s*```(?:json|js|javascript|html|text)?\n?/i, "");
        t = t.replace(/\n?```\s*$/i, "");
        t = t.replace(/^\s*```/g, "").replace(/```\s*$/g, "").trim();
        if (/^`[^`]+`$/.test(t)) t = t.slice(1, -1);
        return t;
      };
      if (typeof response === "object" && response !== null && response.content) {
        response = response.content;
      }
      if (typeof response === "string") response = stripFences(response);
      if (aiMode === "ask") {
        const reasoningText = typeof response === "string" ? response : response.reasoning || JSON.stringify(response);
        const assistantMsg = {
          role: "assistant",
          content: reasoningText,
          filesChanged: null,
          timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString()
        };
        setChatHistory((prev) => [...prev, assistantMsg]);
        setPrompt("");
        setIsGenerating(false);
      } else {
        let aiReasoning = "Changes applied.";
        let filesChanged = null;
        const applyFiles = async (fileMap, reasoning) => {
          try {
            const patch = { files: fileMap, reasoning: reasoning || "AI proposed changes", created_at: (/* @__PURE__ */ new Date()).toISOString() };
            setPendingPatch(patch);
            const rec = await createAIRequest(project?.id || null, selectedModel, prompt, { files: fileMap });
            patch.requestId = rec?.id || null;
            setPendingPatch(patch);
            filesChanged = Object.keys(fileMap);
            setConsoleLogs2((prev) => [...prev, { type: "info", content: `AI produced a patch (${filesChanged.length} file(s)). Review request created: ${patch.requestId || "n/a"}`, timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
            setChatHistory((prev) => [...prev, { role: "assistant", content: `I prepared a non-destructive patch (${filesChanged.join(", ")}). Review it and apply when ready. Request ID: ${patch.requestId || "n/a"}`, filesChanged, timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
            if (confirm(`AI produced changes to: ${filesChanged.join(", ")}.
Apply them now to your workspace? (Cancel to keep as pending request)`)) {
              await applyPendingPatchNow(patch);
            }
          } catch (e) {
            console.error("Failed to create patch request:", e);
            setPendingPatch({ files: fileMap, reasoning: reasoning || "AI proposed changes", requestId: null });
            filesChanged = Object.keys(fileMap);
            setConsoleLogs2((prev) => [...prev, { type: "warn", content: `Patch saved locally as pending. Create request failed: ${e && e.message ? e.message : e}`, timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
          }
        };
        if (typeof response === "string") {
          const maybe = response.trim();
          if (maybe.startsWith("{") || maybe.startsWith("[")) {
            try {
              const parsed = JSON.parse(maybe);
              if (parsed && parsed.files) {
                applyFiles(parsed.files);
                aiReasoning = parsed.reasoning || "Updated multiple files as requested.";
              } else {
                updateFileContent(maybe);
                filesChanged = [activeFile];
              }
            } catch (parseErr) {
              updateFileContent(maybe);
              filesChanged = [activeFile];
            }
          } else {
            const jsonCapture = maybe.match(/({\s*"files"\s*:\s*[\s\S]*\})/m);
            if (jsonCapture && jsonCapture[1]) {
              try {
                const candidate = jsonCapture[1];
                const parsed = JSON.parse(candidate);
                if (parsed && parsed.files && typeof parsed.files === "object") {
                  applyFiles(parsed.files);
                  aiReasoning = parsed.reasoning || "Updated multiple files as requested.";
                } else {
                  updateFileContent(maybe);
                  filesChanged = [activeFile];
                }
              } catch (parseErr) {
                console.warn("JSON extraction failed, writing raw response to active file:", parseErr);
                updateFileContent(maybe);
                filesChanged = [activeFile];
              }
            } else {
              updateFileContent(maybe);
              filesChanged = [activeFile];
            }
          }
        } else if (typeof response === "object" && response.files) {
          applyFiles(response.files);
          aiReasoning = response.reasoning || "Updated multiple files as requested.";
        }
        const changeList = filesChanged && filesChanged.length ? filesChanged : [];
        const shortReason = (aiReasoning || "").split("\n").slice(0, 6).join("\n").trim();
        const assistantMsg = {
          role: "assistant",
          content: shortReason || "Updated workspace.",
          filesChanged: changeList,
          timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString()
        };
        setChatHistory((prev) => [...prev, assistantMsg]);
        setConsoleLogs2((prev) => [...prev, { type: "success", content: `AI applied changes to: ${changeList.length ? changeList.join(", ") : "none"}`, timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
        if (changeList.length) {
          changeList.forEach((fname) => {
            const fcontent = files[fname] || "";
            setConsoleLogs2((prev) => [...prev, { type: "info", content: `${fname} \u2014 ${String(fcontent).slice(0, 200).replace(/\n/g, " ")}${String(fcontent).length > 200 ? "..." : ""}`, timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
          });
        }
        setPrompt("");
        setIsGenerating(false);
      }
    } catch (err) {
      setConsoleLogs2((prev) => [...prev, { type: "error", content: `AI Error: ${err && err.message ? err.message : String(err)}`, timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
      try {
        localStorage.setItem(`ft_last_ai_error_${user?.id}`, String(err && err.message ? err.message : String(err)));
      } catch (_) {
      }
      const fallbackReason = typeof err === "string" ? err : err && err.message ? err.message : "Unknown AI failure";
      const fallbackAssist = aiMode === "ask" ? `\u26A0\uFE0F AI provider failed to respond: ${fallbackReason}

I couldn't reach ${selectedModel.name}. Meanwhile, here's a quick analysis and suggestions based on your prompt:

- Summary: ${prompt.split("\n")[0] || "No prompt provided."}
- Quick suggestions:
  1. Verify imports and dependencies.
  2. Check console/stack traces for file/line.
  3. Ask me to generate a patch or rewrite a specific file.

You can retry or switch models from the picker.` : `\u26A0\uFE0F AI provider failed to respond: ${fallbackReason}

I couldn't reach ${selectedModel.name}. As a fallback I prepared a safe local note for the active file and created a pending patch request you can review.

-- Fallback note inserted into ${activeFile} --
/*
  Fallback assistant note: AI provider (${selectedModel.name}) failed to respond.
  Prompt: ${prompt.replace(/\n/g, " ").slice(0, 400)}
  Recommendation: Retry the model or switch provider. This placeholder was added so you have immediate guidance.
*/
`;
      const assistantMsg = { role: "assistant", content: fallbackAssist, filesChanged: null, timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() };
      setChatHistory((prev) => [...prev, assistantMsg]);
      if (aiMode !== "ask") {
        try {
          const original = files[activeFile] || "";
          const appended = original + `

/* Fallback AI note: ${fallbackReason} */
`;
          const fileMap = { [activeFile]: appended };
          const patch = { files: fileMap, reasoning: `Fallback patch due to AI error: ${fallbackReason}`, created_at: (/* @__PURE__ */ new Date()).toISOString() };
          setPendingPatch(patch);
          try {
            const rec = await createAIRequest(project?.id || null, selectedModel, `Fallback due to error: ${fallbackReason}

Original prompt:
${prompt}`, { files: fileMap });
            patch.requestId = rec?.id || null;
            setPendingPatch(patch);
            setConsoleLogs2((prev) => [...prev, { type: "warn", content: `Fallback patch created (local). Review request id: ${patch.requestId || "n/a"}`, timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
            setChatHistory((prev) => [...prev, { role: "assistant", content: `Fallback patch recorded. Request ID: ${patch.requestId || "n/a"}`, filesChanged: Object.keys(fileMap), timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
          } catch (reqErr) {
            setPendingPatch(patch);
            setConsoleLogs2((prev) => [...prev, { type: "warn", content: `Fallback patch saved locally (request create failed).`, timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
          }
          setFiles((prev) => {
            const merged = { ...prev, ...fileMap };
            onSave({ ...project || {}, files: merged, allowAIEdit });
            return merged;
          });
        } catch (patchErr) {
          setConsoleLogs2((prev) => [...prev, { type: "error", content: `Fallback apply failed: ${patchErr && patchErr.message ? patchErr.message : String(patchErr)}`, timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
        }
      }
      setIsGenerating(false);
    }
  };
  const createFolder = () => {
    const name = safePrompt("Folder name:", "src");
    if (!name) return;
    const newFiles = { ...files, [`${name}/.keep`]: "" };
    setFiles(newFiles);
    onSave({ ...project || {}, files: newFiles, allowAIEdit });
  };
  const createFile = () => {
    const name = safePrompt("File name (can include folders):", "src/newfile.js");
    if (!name) return;
    setFiles((prev) => {
      const nf = { ...prev, [name]: "" };
      onSave({ ...project || {}, files: nf, allowAIEdit });
      return nf;
    });
    setOpenFiles((prev) => {
      if (!prev.includes(name)) return [...prev, name];
      return prev;
    });
    setActiveFile(name);
  };
  const renameFile = (oldName) => {
    const newName = safePrompt("New file name:", oldName);
    if (!newName || newName === oldName) return;
    setFiles((prev) => {
      const nf = { ...prev };
      nf[newName] = nf[oldName];
      delete nf[oldName];
      onSave({ ...project || {}, files: nf, allowAIEdit });
      return nf;
    });
    setOpenFiles((prev) => prev.map((f) => f === oldName ? newName : f));
    setActiveFile(newName);
  };
  const deleteFile = (filename) => {
    if (!confirm(`Delete ${filename}?`)) return;
    setFiles((prev) => {
      const nf = { ...prev };
      delete nf[filename];
      onSave({ ...project || {}, files: nf, allowAIEdit });
      setOpenFiles((prevTabs) => prevTabs.filter((f) => f !== filename));
      setActiveFile((prevActive) => {
        if (prevActive !== filename) return prevActive;
        const remainingOpen = openFiles.filter((f) => f !== filename);
        if (remainingOpen.length) return remainingOpen[0];
        const remainingFiles = Object.keys(nf);
        return remainingFiles[0] || "";
      });
      return nf;
    });
  };
  const publishOptionsToggle = async () => {
    setShowPublishOptions((p) => !p);
  };
  const savePublishOptions = async (changes) => {
    const updatedProject = { ...project || {}, files, allowAIEdit: changes.allowAIEdit, allowAIRead: changes.allowAIRead, published: changes.published ?? project?.published };
    setAllowAIEdit(changes.allowAIEdit);
    setAllowAIRead(changes.allowAIRead ?? allowAIRead);
    onSave(updatedProject);
    setShowPublishOptions(false);
  };
  const openFile = (filename) => {
    if (!filename) return;
    setOpenFiles((prev) => {
      if (prev.includes(filename)) return prev;
      return [...prev, filename];
    });
    setActiveFile(filename);
  };
  const closeFileTab = (filename) => {
    setOpenFiles((prev) => {
      const next = prev.filter((f) => f !== filename);
      if (activeFile === filename) {
        setActiveFile(next[0] || Object.keys(files)[0] || "");
      }
      return next;
    });
  };
  const previewSrcDoc = useMemo(() => {
    const html = files["index.html"] || "";
    const filesJSON = JSON.stringify(files);
    const encoded = btoa(unescape(encodeURIComponent(filesJSON)));
    return `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8" />
          <script src="https://unpkg.com/@babel/standalone/babel.min.js"><\/script>
          <script type="importmap">
          {
            "imports": {
              "react": "https://esm.sh/react@18.2.0",
              "react-dom": "https://esm.sh/react-dom@18.2.0",
              "react-dom/client": "https://esm.sh/react-dom@18.2.0/client"
            }
          }
          <\/script>
          <style>
            ${files["style.css"] || files["styles.css"] || ""}
          </style>
          <script>
            // Rehydrate virtual files from a base64 payload to avoid accidental HTML/content injection into the parent DOM.
            try {
              const decoded = decodeURIComponent(escape(atob("${encoded}")));
              window.virtualFiles = JSON.parse(decoded);
            } catch (e) {
              window.virtualFiles = {};
              console.error("Failed to decode virtualFiles:", e && e.message ? e.message : e);
            }

            // Intercept console
            (function(){
              const originalLog = console.log;
              console.log = function(...args) {
                window.parent.postMessage({ type: 'log', content: args.map(a => typeof a === 'object' ? JSON.stringify(a, null, 2) : a).join(' ') }, '*');
                originalLog.apply(console, args);
              };
              window.onerror = function(msg, url, line, col, error) {
                window.parent.postMessage({ type: 'error', content: msg + ' (line ' + line + ')' }, '*');
              };
            })();

            // Custom Loader for JSX/Modules using window.virtualFiles
            async function boot() {
              const scripts = document.querySelectorAll('script[type="module"]');
              for (const script of scripts) {
                const src = script.getAttribute('src');
                if (src && window.virtualFiles && window.virtualFiles[src]) {
                  try {
                    const transformed = Babel.transform(window.virtualFiles[src], {
                      presets: ['react', 'env'],
                      filename: src
                    }).code;
                    
                    const blob = new Blob([transformed], { type: 'application/javascript' });
                    const url = URL.createObjectURL(blob);
                    
                    const newScript = document.createElement('script');
                    newScript.type = 'module';
                    newScript.src = url;
                    document.head.appendChild(newScript);
                  } catch (e) {
                    console.error("Babel Transform Error in " + src + ":", e && e.message ? e.message : e);
                    window.parent.postMessage({ type: 'error', content: "Babel Transform Error in " + src + ": " + (e && e.message ? e.message : e) }, '*');
                  }
                }
              }
            }
            window.addEventListener('load', boot);

            window.addEventListener('message', (e) => {
              if (e.data.type === 'exec') {
                try {
                  const res = eval(e.data.code);
                  console.log(res);
                } catch (err) {
                  console.error(err);
                }
              }
            });
          <\/script>
        </head>
        <body>
          ${html}
        </body>
      </html>
    `;
  }, [files, previewKey]);
  const openInNewWindow = () => {
    const blob = new Blob([previewSrcDoc], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    window.open(url, "_blank");
  };
  const handleAssetUpload = async () => {
    try {
      const input = document.createElement("input");
      input.type = "file";
      input.multiple = true;
      input.accept = "image/*,audio/*,video/*,application/zip,*/*";
      input.style.display = "none";
      document.body.appendChild(input);
      const pick = () => new Promise((resolve) => {
        input.onchange = () => resolve(Array.from(input.files || []));
        input.click();
      });
      const filesPicked = await pick();
      document.body.removeChild(input);
      if (!filesPicked || filesPicked.length === 0) return;
      for (const file of filesPicked) {
        setConsoleLogs2((prev) => [...prev, { type: "info", content: `Uploading ${file.name}...`, timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
        if (window.websim && typeof window.websim.upload === "function") {
          try {
            const url = await window.websim.upload(file);
            const assetPath = `assets/${file.name}`;
            const updated = { ...files, [assetPath]: url };
            setFiles(updated);
            onSave({ ...project || {}, files: updated, allowAIEdit });
            setConsoleLogs2((prev) => [...prev, { type: "success", content: `Uploaded ${file.name} -> ${url}`, timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
            continue;
          } catch (e) {
            console.warn("websim.upload failed, falling back:", e);
          }
        }
        try {
          const ok = await HFRepoManager.uploadToHuggingFace(file);
          if (ok && ok.url) {
            const assetPath = `assets/${file.name}`;
            const updated = { ...files, [assetPath]: ok.url };
            setFiles(updated);
            onSave({ ...project || {}, files: updated, allowAIEdit });
            setConsoleLogs2((prev) => [...prev, { type: "success", content: `Uploaded ${file.name} -> ${ok.url}`, timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
          } else {
            setConsoleLogs2((prev) => [...prev, { type: "warn", content: `Upload returned no URL for ${file.name}`, timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
            alert(`Upload failed for ${file.name}. Check console for details.`);
          }
        } catch (e) {
          console.error("Asset upload fallback failed:", e);
          setConsoleLogs2((prev) => [...prev, { type: "error", content: `Upload failed: ${e && e.message ? e.message : e}`, timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
          alert(`Asset upload failed for ${file.name}.`);
        }
      }
    } catch (e) {
      console.error("handleAssetUpload error:", e);
      alert("Asset upload failed. See console.");
    }
  };
  useEffect(() => {
    const parseStackForLocation = (text) => {
      const locRegex = /(?:\()?(?:.*?)([A-Za-z0-9_\-./]+(?:\.[a-zA-Z]{1,5}))(?:[:@])(\d{1,6})(?::(\d{1,6}))?(?:\))?/;
      const m = String(text).match(locRegex);
      if (!m) return null;
      return { file: m[1], line: parseInt(m[2] || "0", 10), col: m[3] ? parseInt(m[3], 10) : null };
    };
    const severityFromMessage = (msg) => {
      const t = String(msg).toLowerCase();
      if (t.includes("uncaught") || t.includes("error") || t.includes("exception") || t.includes("failed")) return "error";
      if (t.includes("warn") || t.includes("deprecated") || t.includes("warning")) return "warn";
      return "info";
    };
    const generateQuickFixes = (raw, loc) => {
      const fixes = [];
      const s = String(raw).toLowerCase();
      if (s.includes("cannot read property") || s.includes("cannot read")) {
        fixes.push({ title: "Null-check or optional chaining", detail: "Add a null-check or use optional chaining (?.) before accessing properties." });
      }
      if (s.includes("is not a function") || s.includes("not a function")) {
        fixes.push({ title: "Verify import / function name", detail: "Ensure the symbol is imported correctly and that it is a function. Check default vs named imports." });
      }
      if (s.includes("unexpected token") || s.includes("syntaxerror")) {
        fixes.push({ title: "Check syntax / missing bracket", detail: "Look for unclosed braces/brackets, or JSX needing parentheses. Run a syntax check or Babel transform locally." });
      }
      if (s.includes("module not found") || s.includes("failed to fetch")) {
        fixes.push({ title: "Missing asset / module", detail: "Confirm path and that the file exists in the workspace or update the import URL." });
      }
      if (s.includes("cross origin") || s.includes("cors")) {
        fixes.push({ title: "CORS issue", detail: "Serve assets from same-origin or set CORS headers on the resource." });
      }
      if (loc && loc.file) {
        fixes.unshift({ title: "Generate AI patch for this file", detail: `Ask the AI to propose a patch for ${loc.file} at approx line ${loc.line || "?"}.`, aiPatch: true, targetFile: loc.file, targetLine: loc.line });
      }
      fixes.push({ title: "Show full stack trace", detail: "Open the console logs and inspect preceding messages for context." });
      return fixes;
    };
    const requestAIPatch = async (loc, raw, model = MODELS[0]) => {
      try {
        const title = `Quick fix for ${loc?.file || "unknown file"}`;
        const prompt2 = `ERROR CONTEXT:
${String(raw).slice(0, 1200)}

Please propose a minimal patch or code change to fix the error referencing ${loc?.file || "unknown"} at line ${loc?.line || "?"}.
Return JSON with {"files": {"path": "content"}, "reasoning": "..."}.`;
        const rec = await createAIRequest(project?.id || null, model, prompt2, null);
        return rec.id;
      } catch (e) {
        console.warn("AI patch request failed:", e);
        return null;
      }
    };
    const handleMessage = (e) => {
      try {
        const payload = e && e.data ? e.data : null;
        if (!payload) return;
        let raw = payload.content ?? payload;
        let type = "info";
        if (payload.type === "error" || payload.type === "err" || String(raw).toLowerCase().includes("error")) type = "error";
        else if (payload.type === "warn" || String(raw).toLowerCase().includes("warn")) type = "warn";
        else if (payload.type === "log") type = "info";
        const severity = severityFromMessage(raw);
        const loc = parseStackForLocation(raw);
        const timestamp = (/* @__PURE__ */ new Date()).toLocaleTimeString();
        const entry = {
          type: severity === "error" ? "error" : severity === "warn" ? "warn" : "info",
          content: String(raw),
          timestamp,
          file: loc ? loc.file : null,
          line: loc ? loc.line : null,
          col: loc ? loc.col : null
        };
        setConsoleLogs2((prev) => {
          const next = [...prev, entry];
          if (next.length > 300) next.splice(0, next.length - 300);
          return next;
        });
        if (entry.type === "error") {
          setShowConsole(true);
          const fixes = generateQuickFixes(entry.content, loc);
          setConsoleLogs2((prev) => [...prev, { type: "info", content: `Quick fixes suggested:
${fixes.map((f, i) => `${i + 1}. ${f.title} \u2014 ${f.detail}`).join("\n")}`, timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
          const assistantMsg = {
            role: "assistant",
            content: `Detected runtime error: ${entry.content}

Suggested quick fixes:
${fixes.map((f, i) => `${i + 1}. **${f.title}** \u2014 ${f.detail}`).join("\n")}

Actions:
- Click a suggestion in console to apply (non-destructive) or request an AI patch.`,
            filesChanged: null,
            timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString()
          };
          setChatHistory((prev) => [...prev, assistantMsg]);
          const aiFix = fixes.find((f) => f.aiPatch);
          if (aiFix && project) {
            requestAIPatch({ file: aiFix.targetFile, line: aiFix.targetLine }, entry.content).then((reqId) => {
              if (reqId) {
                setConsoleLogs2((prev) => [...prev, { type: "success", content: `AI patch request created: ${reqId} \u2014 review in Requests panel.`, timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
                setChatHistory((prev) => [...prev, { role: "assistant", content: `I've created an AI patch request (${reqId}) you can review and apply.`, filesChanged: null, timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
              }
            }).catch((err) => {
              setConsoleLogs2((prev) => [...prev, { type: "error", content: `Failed to create AI patch request: ${err && err.message ? err.message : err}`, timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
            });
          }
          if (loc && loc.file) {
            const candidates = Object.keys(files || {});
            const exact = candidates.find((c) => c.endsWith(loc.file));
            const basename = loc.file.split("/").pop();
            const fuzzy = candidates.find((c) => c.split("/").pop() === basename);
            const target = exact || fuzzy;
            if (target) {
              openFile(target);
              setConsoleLogs2((prev) => [...prev, { type: "info", content: `Located error in workspace file: ${target} (line ${loc.line || "?"}) \u2014 opened in editor.`, timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
            } else {
              setConsoleLogs2((prev) => [...prev, { type: "warn", content: `Error references external file: ${loc.file}. If it's part of your bundle, consider adding it to the workspace for editing.`, timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
            }
          }
        }
      } catch (err) {
        console.warn("Enhanced message handler caught:", err && err.message ? err.message : err);
      }
    };
    window.addEventListener("message", handleMessage);
    return () => window.removeEventListener("message", handleMessage);
  }, [files, openFile, setShowConsole, project]);
  const fileTree = useMemo(() => {
    const tree = {};
    Object.keys(files).sort().forEach((f) => {
      const parts = f.split("/");
      if (parts.length > 1) {
        const folder = parts.slice(0, parts.length - 1).join("/");
        tree[folder] = tree[folder] || [];
        tree[folder].push(f);
      } else {
        tree[".root"] = tree[".root"] || [];
        tree[".root"].push(f);
      }
    });
    return tree;
  }, [files]);
  const renderMessageHtml = (raw) => {
    try {
      const md = typeof raw === "string" ? raw : String(raw);
      marked.setOptions({ gfm: true, breaks: true, smartLists: true });
      let preprocessed = md.replace(/^(🛠️|✅|🔎|ℹ️|⚠️|❗|💡)\s*/gm, "#### $1 ").replace(/(^|\n)(-{3,}|\*{3,}|_{3,})(\n|$)/g, "\n\n---\n\n");
      preprocessed = preprocessed.replace(/(^|\n)(\s*(Thoughts|Reasoning|Analysis|Assistant Analysis)\s*:)/ig, "\n\n> **$2**\n\n");
      let html = marked.parse(preprocessed || "");
      const filenames = Object.keys(files).sort((a, b) => b.length - a.length);
      filenames.forEach((fname) => {
        const safeFname = fname.replace(/[-/\\^$*+?.()|[\]{}]/g, "\\$&");
        const regexBacktick = new RegExp("`(" + safeFname + ")`", "g");
        html = html.replace(regexBacktick, `<a href="#" data-fname="${fname}" class="text-indigo-400 font-bold hover:underline">$1</a>`);
      });
      return DOMPurify.sanitize(html, { ADD_ATTR: ["data-fname"] });
    } catch (e) {
      return DOMPurify.sanitize(marked.parse(String(raw || "")));
    }
  };
  useEffect(() => {
    const handler = (e) => {
      const el = e.target;
      if (el && el.dataset && el.dataset.fname) {
        e.preventDefault();
        const fname = el.dataset.fname;
        if (files[fname]) openFile(fname);
      } else {
        const anchor = el.closest && el.closest("a[data-fname]");
        if (anchor && anchor.dataset && anchor.dataset.fname) {
          e.preventDefault();
          const fname = anchor.dataset.fname;
          if (files[fname]) openFile(fname);
        }
      }
    };
    const chatContainer = document.querySelector(".right-bar-chat") || document.body;
    chatContainer.addEventListener("click", handler);
    return () => chatContainer.removeEventListener("click", handler);
  }, [files, openFile]);
  const [comments, setComments] = useState([]);
  useEffect(() => {
    const fetchComments = async () => {
      try {
        const project2 = await window.websim.getCurrentProject();
        const response = await fetch(`/api/v1/projects/${project2.id}/comments`);
        const data = await response.json();
        setComments(data.comments.data || []);
      } catch (e) {
      }
    };
    fetchComments();
    const unsubscribe = window.websim.addEventListener("comment:created", (data) => {
      setComments((prev) => [data, ...prev]);
    });
    return () => unsubscribe && typeof unsubscribe === "function" && unsubscribe();
  }, []);
  return /* @__PURE__ */ jsxDEV("div", { className: "flex h-full w-full bg-[#050505] flex-col md:flex-row overflow-hidden", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "w-full md:w-72 border-r border-white/5 flex flex-col bg-slate-950/40 backdrop-blur-xl", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "p-5 flex items-center justify-between border-b border-white/5", children: [
        /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-black text-slate-500 uppercase tracking-widest", children: "Workspace" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 1620,
          columnNumber: 11
        }),
        /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [
          /* @__PURE__ */ jsxDEV("button", { onClick: createFile, className: "p-1.5 hover:bg-white/5 rounded-lg text-slate-400 hover:text-white transition-colors", children: /* @__PURE__ */ jsxDEV(Plus, { size: 16 }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 1623,
            columnNumber: 15
          }) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 1622,
            columnNumber: 13
          }),
          /* @__PURE__ */ jsxDEV("button", { onClick: createFolder, className: "p-1.5 hover:bg-white/5 rounded-lg text-slate-400 hover:text-white transition-colors", children: /* @__PURE__ */ jsxDEV(Folder, { size: 16 }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 1626,
            columnNumber: 15
          }) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 1625,
            columnNumber: 13
          }),
          /* @__PURE__ */ jsxDEV("button", { onClick: publishOptionsToggle, className: "p-1.5 hover:bg-white/5 rounded-lg text-slate-400 hover:text-white transition-colors", children: /* @__PURE__ */ jsxDEV(Share2, { size: 16 }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 1629,
            columnNumber: 15
          }) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 1628,
            columnNumber: 13
          })
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 1621,
          columnNumber: 11
        })
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 1619,
        columnNumber: 9
      }),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow overflow-y-auto p-2 space-y-1", children: [
        (fileTree[".root"] || []).map((filename) => /* @__PURE__ */ jsxDEV(
          "div",
          {
            onClick: () => {
              openFile(filename);
            },
            className: `flex items-center gap-3 px-4 py-2 rounded-xl cursor-pointer group transition-all ${activeFile === filename ? "bg-indigo-500/15 text-indigo-300 shadow-sm" : "text-slate-400 hover:bg-white/5 hover:text-slate-200"}`,
            children: [
              /* @__PURE__ */ jsxDEV(FileIcon, { filename, size: 16 }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 1642,
                columnNumber: 15
              }),
              /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-semibold truncate flex-grow", children: filename }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 1643,
                columnNumber: 15
              }),
              /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2 opacity-0 group-hover:opacity-100", children: [
                /* @__PURE__ */ jsxDEV("button", { onClick: (e) => {
                  e.stopPropagation();
                  renameFile(filename);
                }, className: "p-1 hover:text-indigo-400", children: /* @__PURE__ */ jsxDEV(Edit3, { size: 12 }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 1645,
                  columnNumber: 125
                }) }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 1645,
                  columnNumber: 17
                }),
                /* @__PURE__ */ jsxDEV("button", { onClick: (e) => {
                  e.stopPropagation();
                  deleteFile(filename);
                }, className: "p-1 hover:text-red-500", children: /* @__PURE__ */ jsxDEV(Trash2, { size: 12 }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 1646,
                  columnNumber: 122
                }) }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 1646,
                  columnNumber: 17
                })
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 1644,
                columnNumber: 15
              })
            ]
          },
          filename,
          true,
          {
            fileName: "<stdin>",
            lineNumber: 1637,
            columnNumber: 13
          }
        )),
        Object.keys(fileTree).filter((k) => k !== ".root").map((folder) => /* @__PURE__ */ jsxDEV("div", { className: "space-y-1", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "px-4 py-2.5 rounded-xl text-slate-300 font-bold", children: folder }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 1654,
            columnNumber: 15
          }),
          /* @__PURE__ */ jsxDEV("div", { className: "space-y-1 pl-4", children: fileTree[folder].map((filename) => /* @__PURE__ */ jsxDEV(
            "div",
            {
              onClick: () => openFile(filename),
              className: `flex items-center gap-3 px-4 py-2.5 rounded-xl cursor-pointer group transition-all ${activeFile === filename ? "bg-indigo-500/10 text-indigo-400 shadow-sm" : "text-slate-400 hover:bg-white/5 hover:text-slate-200"}`,
              children: [
                /* @__PURE__ */ jsxDEV(FileCode, { size: 14 }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 1662,
                  columnNumber: 21
                }),
                /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-semibold truncate flex-grow", children: filename.split("/").pop() }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 1663,
                  columnNumber: 21
                }),
                /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2 opacity-0 group-hover:opacity-100", children: [
                  /* @__PURE__ */ jsxDEV("button", { onClick: (e) => {
                    e.stopPropagation();
                    renameFile(filename);
                  }, className: "p-1 hover:text-indigo-400", children: /* @__PURE__ */ jsxDEV(Edit3, { size: 12 }, void 0, false, {
                    fileName: "<stdin>",
                    lineNumber: 1665,
                    columnNumber: 131
                  }) }, void 0, false, {
                    fileName: "<stdin>",
                    lineNumber: 1665,
                    columnNumber: 23
                  }),
                  /* @__PURE__ */ jsxDEV("button", { onClick: (e) => {
                    e.stopPropagation();
                    deleteFile(filename);
                  }, className: "p-1 hover:text-red-500", children: /* @__PURE__ */ jsxDEV(Trash2, { size: 12 }, void 0, false, {
                    fileName: "<stdin>",
                    lineNumber: 1666,
                    columnNumber: 128
                  }) }, void 0, false, {
                    fileName: "<stdin>",
                    lineNumber: 1666,
                    columnNumber: 23
                  })
                ] }, void 0, true, {
                  fileName: "<stdin>",
                  lineNumber: 1664,
                  columnNumber: 21
                })
              ]
            },
            filename,
            true,
            {
              fileName: "<stdin>",
              lineNumber: 1657,
              columnNumber: 19
            }
          )) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 1655,
            columnNumber: 15
          })
        ] }, folder, true, {
          fileName: "<stdin>",
          lineNumber: 1653,
          columnNumber: 13
        }))
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 1634,
        columnNumber: 9
      })
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 1618,
      columnNumber: 7
    }),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow flex flex-col min-w-0 bg-[#080808]", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "h-14 border-b border-white/5 flex items-center justify-between px-6 bg-[#0a0a0a]", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV(Code2, { size: 18, className: "text-indigo-400" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 1683,
              columnNumber: 16
            }),
            /* @__PURE__ */ jsxDEV("span", { className: "text-sm font-black text-white", children: project?.name }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 1684,
              columnNumber: 16
            })
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 1682,
            columnNumber: 13
          }),
          /* @__PURE__ */ jsxDEV("div", { className: "h-4 w-[1px] bg-white/10" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 1686,
            columnNumber: 13
          }),
          /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2 items-center", children: /* @__PURE__ */ jsxDEV("div", { className: "flex gap-1 max-w-[600px] overflow-x-auto pr-2", children: openFiles.map((f) => /* @__PURE__ */ jsxDEV(
            "div",
            {
              onClick: () => setActiveFile(f),
              className: `flex items-center gap-2 px-3 py-1 rounded-xl cursor-pointer select-none ${activeFile === f ? "bg-indigo-500 text-white shadow" : "text-slate-400 bg-white/0 hover:bg-white/5"}`,
              children: [
                /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-mono truncate max-w-[200px]", children: f.split("/").pop() }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 1696,
                  columnNumber: 21
                }),
                /* @__PURE__ */ jsxDEV("button", { onClick: (e) => {
                  e.stopPropagation();
                  closeFileTab(f);
                }, className: "text-slate-300 hover:text-white p-0.5", children: /* @__PURE__ */ jsxDEV(X, { size: 12 }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 1698,
                  columnNumber: 23
                }) }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 1697,
                  columnNumber: 21
                })
              ]
            },
            f,
            true,
            {
              fileName: "<stdin>",
              lineNumber: 1691,
              columnNumber: 19
            }
          )) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 1689,
            columnNumber: 15
          }) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 1687,
            columnNumber: 13
          }),
          /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-bold text-slate-500 italic", children: [
            "/",
            activeFile
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 1704,
            columnNumber: 13
          })
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 1681,
          columnNumber: 11
        }),
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center bg-white/5 rounded-xl px-2 gap-1 mr-2", children: [
            /* @__PURE__ */ jsxDEV(History, { size: 14, className: "text-slate-500" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 1708,
              columnNumber: 15
            }),
            /* @__PURE__ */ jsxDEV(
              "select",
              {
                value: currentVersion,
                onChange: (e) => loadVersion(Number(e.target.value)),
                className: "bg-transparent border-none text-[10px] font-black text-indigo-400 outline-none py-2 cursor-pointer",
                children: [
                  /* @__PURE__ */ jsxDEV("option", { value: project?.version || 1, className: "bg-slate-900", children: [
                    "V",
                    project?.version || 1,
                    " (Latest)"
                  ] }, void 0, true, {
                    fileName: "<stdin>",
                    lineNumber: 1714,
                    columnNumber: 17
                  }),
                  (project?.history || []).map((h) => /* @__PURE__ */ jsxDEV("option", { value: h.version, className: "bg-slate-900", children: [
                    "V",
                    h.version
                  ] }, h.version, true, {
                    fileName: "<stdin>",
                    lineNumber: 1716,
                    columnNumber: 19
                  }))
                ]
              },
              void 0,
              true,
              {
                fileName: "<stdin>",
                lineNumber: 1709,
                columnNumber: 15
              }
            )
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 1707,
            columnNumber: 13
          }),
          /* @__PURE__ */ jsxDEV("button", { onClick: saveVersion, className: "p-2 text-indigo-400 hover:bg-indigo-500/10 rounded-xl transition-all", title: "Create Version Snapshot", children: /* @__PURE__ */ jsxDEV(Plus, { size: 18 }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 1721,
            columnNumber: 15
          }) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 1720,
            columnNumber: 13
          }),
          /* @__PURE__ */ jsxDEV("button", { onClick: handleAssetUpload, className: "p-2 text-slate-400 hover:text-indigo-400 rounded-xl hover:bg-white/5 transition-all", title: "Upload Image/Audio/Video", children: /* @__PURE__ */ jsxDEV(Download, { size: 18 }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 1724,
            columnNumber: 15
          }) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 1723,
            columnNumber: 13
          }),
          /* @__PURE__ */ jsxDEV("button", { onClick: openInNewWindow, className: "p-2 text-slate-400 hover:text-indigo-400 rounded-xl hover:bg-white/5 transition-all", title: "Open in New Window (Blob)", children: /* @__PURE__ */ jsxDEV(Globe, { size: 18 }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 1727,
            columnNumber: 15
          }) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 1726,
            columnNumber: 13
          }),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: async () => {
                try {
                  const JSZip = (await import("https://esm.sh/jszip@3.10.0")).default || await import("https://esm.sh/jszip@3.10.0");
                  const zip = new JSZip();
                  const entries = Object.entries(files || {});
                  if (entries.length === 0) {
                    alert("Workspace is empty \u2014 nothing to include in ZIP.");
                    return;
                  }
                  for (const [path, content] of entries) {
                    zip.file(path, content === null || content === void 0 ? "" : String(content));
                  }
                  const blob = await zip.generateAsync({ type: "blob" });
                  const nameSafe = (project?.name || "workspace").replace(/[^\w\-_. ]/g, "_");
                  const a = document.createElement("a");
                  a.href = URL.createObjectURL(blob);
                  a.download = `${nameSafe}.zip`;
                  document.body.appendChild(a);
                  a.click();
                  a.remove();
                  setConsoleLogs2((prev) => [...prev, { type: "success", content: `Exported workspace as ${nameSafe}.zip`, timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
                } catch (err) {
                  console.error("ZIP export failed:", err);
                  setConsoleLogs2((prev) => [...prev, { type: "error", content: `ZIP export failed: ${err && err.message ? err.message : err}`, timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
                  alert("Failed to export ZIP. Check console for details.");
                }
              },
              className: "p-2 text-slate-400 hover:text-indigo-400 rounded-xl hover:bg-white/5 transition-all",
              title: "Download Project ZIP",
              children: /* @__PURE__ */ jsxDEV(Download, { size: 18 }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 1764,
                columnNumber: 15
              })
            },
            void 0,
            false,
            {
              fileName: "<stdin>",
              lineNumber: 1730,
              columnNumber: 13
            }
          ),
          /* @__PURE__ */ jsxDEV("div", { className: "h-4 w-[1px] bg-white/10 mx-1" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 1767,
            columnNumber: 13
          }),
          /* @__PURE__ */ jsxDEV("button", { onClick: handleRun, className: "flex items-center gap-2 text-xs font-black px-5 py-2 bg-indigo-500 hover:bg-indigo-400 text-white rounded-xl transition-all shadow-lg shadow-indigo-600/20 active:scale-95", children: [
            /* @__PURE__ */ jsxDEV(Play, { size: 14, fill: "currentColor" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 1769,
              columnNumber: 15
            }),
            " RUN"
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 1768,
            columnNumber: 13
          }),
          /* @__PURE__ */ jsxDEV(
            "button",
            {
              onClick: publishOptionsToggle,
              title: "Publish / Options",
              className: "p-2.5 text-slate-400 hover:text-indigo-400 rounded-xl hover:bg-white/5 transition-all",
              children: /* @__PURE__ */ jsxDEV(Share2, { size: 18 }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 1777,
                columnNumber: 15
              })
            },
            void 0,
            false,
            {
              fileName: "<stdin>",
              lineNumber: 1772,
              columnNumber: 13
            }
          ),
          /* @__PURE__ */ jsxDEV("button", { onClick: () => {
            onSave({ ...project || {}, files, allowAIEdit });
            setConsoleLogs2((prev) => [...prev, { type: "success", content: "Saved workspace.", timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString() }]);
          }, className: "p-2.5 text-slate-400 hover:text-white rounded-xl hover:bg-white/5 transition-all", children: /* @__PURE__ */ jsxDEV(Save, { size: 18 }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 1784,
            columnNumber: 15
          }) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 1780,
            columnNumber: 13
          })
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 1706,
          columnNumber: 11
        })
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 1680,
        columnNumber: 9
      }),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow flex flex-col relative min-h-0 editor-container", children: /* @__PURE__ */ jsxDEV(
        Editor,
        {
          height: "100%",
          theme: "vs-dark",
          path: activeFile,
          defaultLanguage: activeFile.split(".").pop() === "js" ? "javascript" : activeFile.split(".").pop(),
          value: activeContent,
          onChange: (val) => updateFileContent(val, activeFile),
          onMount: handleMonacoMount,
          options: {
            minimap: { enabled: false },
            fontSize: 14,
            fontFamily: "Fira Code, monospace",
            padding: { top: 20 },
            smoothScrolling: true,
            cursorSmoothCaretAnimation: "on",
            roundedSelection: true,
            lineNumbers: "on",
            automaticLayout: true,
            scrollbar: { vertical: "hidden", horizontal: "hidden" },
            backgroundColor: "#080808",
            className: "monaco-editor-vibe"
          }
        },
        void 0,
        false,
        {
          fileName: "<stdin>",
          lineNumber: 1790,
          columnNumber: 11
        }
      ) }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 1789,
        columnNumber: 9
      })
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 1679,
      columnNumber: 7
    }),
    /* @__PURE__ */ jsxDEV(
      "div",
      {
        style: { width: chatPanelWidth },
        className: "h-full flex flex-col border-l border-white/5 bg-[#050505] relative transition-all",
        children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex border-b border-white/5 bg-[#0a0a0a]", children: [
            /* @__PURE__ */ jsxDEV("button", { onClick: () => setActiveTab("preview"), className: `flex-grow py-4 text-[10px] font-black tracking-widest uppercase transition-all ${activeTab === "preview" ? "text-indigo-400 bg-indigo-400/5" : "text-slate-500 hover:text-slate-300"}`, children: "Preview" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 1822,
              columnNumber: 11
            }),
            /* @__PURE__ */ jsxDEV("button", { onClick: () => setActiveTab("refining"), className: `flex-grow py-4 text-[10px] font-black tracking-widest uppercase transition-all ${activeTab === "refining" ? "text-indigo-400 bg-indigo-400/5" : "text-slate-500 hover:text-slate-300"}`, children: "Refining" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 1823,
              columnNumber: 11
            }),
            /* @__PURE__ */ jsxDEV("button", { onClick: () => setActiveTab("finenet"), className: `flex-grow py-4 text-[10px] font-black tracking-widest uppercase transition-all ${activeTab === "finenet" ? "text-amber-400 bg-amber-400/5" : "text-slate-500 hover:text-slate-300"}`, children: "FineNet" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 1824,
              columnNumber: 11
            }),
            /* @__PURE__ */ jsxDEV("button", { onClick: () => setActiveTab("extensions"), className: `flex-grow py-4 text-[10px] font-black tracking-widest uppercase transition-all ${activeTab === "extensions" ? "text-emerald-400 bg-emerald-400/5" : "text-slate-500 hover:text-slate-300"}`, children: "Extensions" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 1825,
              columnNumber: 11
            })
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 1821,
            columnNumber: 9
          }),
          /* @__PURE__ */ jsxDEV("div", { className: "flex-grow overflow-hidden flex flex-col relative", children: [
            /* @__PURE__ */ jsxDEV(AnimatePresence, { mode: "wait", children: [
              activeTab === "preview" && /* @__PURE__ */ jsxDEV(motion.div, { initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 }, className: "h-full w-full bg-white relative flex flex-col", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex-grow relative", children: [
                  /* @__PURE__ */ jsxDEV(
                    "iframe",
                    {
                      srcDoc: previewSrcDoc,
                      className: "w-full h-full",
                      ref: iframeRef
                    },
                    void 0,
                    false,
                    {
                      fileName: "<stdin>",
                      lineNumber: 1833,
                      columnNumber: 20
                    }
                  ),
                  /* @__PURE__ */ jsxDEV(
                    "button",
                    {
                      onClick: () => setShowConsole(!showConsole),
                      className: `absolute bottom-6 right-6 p-3 rounded-2xl shadow-xl transition-all z-20 ${showConsole ? "bg-indigo-500 text-white" : "bg-slate-900 text-slate-400 border border-white/10"}`,
                      children: /* @__PURE__ */ jsxDEV(Terminal, { size: 20 }, void 0, false, {
                        fileName: "<stdin>",
                        lineNumber: 1842,
                        columnNumber: 22
                      })
                    },
                    void 0,
                    false,
                    {
                      fileName: "<stdin>",
                      lineNumber: 1838,
                      columnNumber: 20
                    }
                  )
                ] }, void 0, true, {
                  fileName: "<stdin>",
                  lineNumber: 1832,
                  columnNumber: 18
                }),
                /* @__PURE__ */ jsxDEV("div", { className: "h-1/3 bg-[#0a0a0a] border-t border-white/10 overflow-y-auto p-4 space-y-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between border-b border-white/5 pb-2 mb-2", children: [
                    /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-black uppercase text-slate-500 tracking-widest", children: "Community Feedback" }, void 0, false, {
                      fileName: "<stdin>",
                      lineNumber: 1848,
                      columnNumber: 22
                    }),
                    /* @__PURE__ */ jsxDEV("button", { onClick: () => window.websim.postComment({ content: "Vibe check: This looks great!" }), className: "text-[10px] font-bold text-indigo-400 hover:underline", children: "Add Comment" }, void 0, false, {
                      fileName: "<stdin>",
                      lineNumber: 1849,
                      columnNumber: 22
                    })
                  ] }, void 0, true, {
                    fileName: "<stdin>",
                    lineNumber: 1847,
                    columnNumber: 20
                  }),
                  comments.map((c, i) => /* @__PURE__ */ jsxDEV("div", { className: "flex gap-3 text-xs", children: [
                    /* @__PURE__ */ jsxDEV("img", { src: c.comment.author.avatar_url, className: "w-6 h-6 rounded-full" }, void 0, false, {
                      fileName: "<stdin>",
                      lineNumber: 1853,
                      columnNumber: 24
                    }),
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "font-black text-slate-300", children: [
                        "@",
                        c.comment.author.username
                      ] }, void 0, true, {
                        fileName: "<stdin>",
                        lineNumber: 1855,
                        columnNumber: 26
                      }),
                      /* @__PURE__ */ jsxDEV("p", { className: "text-slate-400 mt-1 leading-relaxed", children: c.comment.raw_content }, void 0, false, {
                        fileName: "<stdin>",
                        lineNumber: 1856,
                        columnNumber: 26
                      })
                    ] }, void 0, true, {
                      fileName: "<stdin>",
                      lineNumber: 1854,
                      columnNumber: 24
                    })
                  ] }, i, true, {
                    fileName: "<stdin>",
                    lineNumber: 1852,
                    columnNumber: 22
                  }))
                ] }, void 0, true, {
                  fileName: "<stdin>",
                  lineNumber: 1846,
                  columnNumber: 18
                })
              ] }, "preview", true, {
                fileName: "<stdin>",
                lineNumber: 1831,
                columnNumber: 15
              }),
              activeTab === "refining" && /* @__PURE__ */ jsxDEV(motion.div, { initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 }, className: "h-full flex flex-col relative bg-[radial-gradient(circle_at_bottom_left,_rgba(99,102,241,0.05),_transparent)]", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex-grow overflow-y-auto p-6 space-y-6 pb-40", children: [
                  chatHistory.length === 0 && /* @__PURE__ */ jsxDEV("div", { className: "h-full flex flex-col items-center justify-center text-center space-y-4 opacity-50", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "w-16 h-16 rounded-3xl bg-white/5 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV(MessageSquare, { size: 32 }, void 0, false, {
                      fileName: "<stdin>",
                      lineNumber: 1870,
                      columnNumber: 27
                    }) }, void 0, false, {
                      fileName: "<stdin>",
                      lineNumber: 1869,
                      columnNumber: 25
                    }),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-medium max-w-[200px]", children: "Prompt your workspace to begin the refinement process." }, void 0, false, {
                      fileName: "<stdin>",
                      lineNumber: 1872,
                      columnNumber: 25
                    })
                  ] }, void 0, true, {
                    fileName: "<stdin>",
                    lineNumber: 1868,
                    columnNumber: 22
                  }),
                  chatHistory.map((msg, i) => /* @__PURE__ */ jsxDEV("div", { className: `flex ${msg.role === "user" ? "justify-end" : "justify-start"}`, children: /* @__PURE__ */ jsxDEV("div", { className: `max-w-[90%] p-5 rounded-2xl text-sm font-medium leading-relaxed ft-message-card ${msg.role === "user" ? "border-indigo-500/30" : "border-white/5"}`, children: [
                    msg.role === "assistant" && /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 mb-3", children: [
                      /* @__PURE__ */ jsxDEV(Sparkles, { size: 14, className: "text-indigo-400" }, void 0, false, {
                        fileName: "<stdin>",
                        lineNumber: 1880,
                        columnNumber: 31
                      }),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-black uppercase tracking-tighter text-slate-500", children: "FineTunes Assistant" }, void 0, false, {
                        fileName: "<stdin>",
                        lineNumber: 1881,
                        columnNumber: 31
                      })
                    ] }, void 0, true, {
                      fileName: "<stdin>",
                      lineNumber: 1879,
                      columnNumber: 29
                    }),
                    /* @__PURE__ */ jsxDEV(
                      "div",
                      {
                        className: "prose prose-invert prose-sm max-w-none prose-headings:text-white prose-a:text-indigo-400",
                        dangerouslySetInnerHTML: { __html: renderMessageHtml(msg.content) }
                      },
                      void 0,
                      false,
                      {
                        fileName: "<stdin>",
                        lineNumber: 1884,
                        columnNumber: 27
                      }
                    ),
                    msg.role === "assistant" && msg.filesChanged && /* @__PURE__ */ jsxDEV("div", { className: "mt-2 text-[11px] text-slate-400 border-t border-white/5 pt-2", children: [
                      /* @__PURE__ */ jsxDEV("div", { className: "font-bold text-[10px] uppercase tracking-widest mb-1 text-indigo-400", children: "Changed Workspace Files:" }, void 0, false, {
                        fileName: "<stdin>",
                        lineNumber: 1890,
                        columnNumber: 31
                      }),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-1.5 mt-2", children: msg.filesChanged.map((f) => /* @__PURE__ */ jsxDEV(
                        "button",
                        {
                          onClick: () => openFile(f),
                          className: "px-2 py-0.5 bg-indigo-500/10 border border-indigo-500/20 rounded-md text-[9px] font-mono text-indigo-300 hover:bg-indigo-500/20 transition-colors",
                          children: f
                        },
                        f,
                        false,
                        {
                          fileName: "<stdin>",
                          lineNumber: 1893,
                          columnNumber: 35
                        }
                      )) }, void 0, false, {
                        fileName: "<stdin>",
                        lineNumber: 1891,
                        columnNumber: 31
                      })
                    ] }, void 0, true, {
                      fileName: "<stdin>",
                      lineNumber: 1889,
                      columnNumber: 29
                    })
                  ] }, void 0, true, {
                    fileName: "<stdin>",
                    lineNumber: 1877,
                    columnNumber: 25
                  }) }, i, false, {
                    fileName: "<stdin>",
                    lineNumber: 1876,
                    columnNumber: 22
                  })),
                  /* @__PURE__ */ jsxDEV("div", { ref: chatEndRef }, void 0, false, {
                    fileName: "<stdin>",
                    lineNumber: 1907,
                    columnNumber: 20
                  })
                ] }, void 0, true, {
                  fileName: "<stdin>",
                  lineNumber: 1866,
                  columnNumber: 18
                }),
                /* @__PURE__ */ jsxDEV("div", { className: "absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-[#050505] via-[#050505] to-transparent", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-2", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [
                    /* @__PURE__ */ jsxDEV(
                      "button",
                      {
                        onClick: () => setShowModelPicker(!showModelPicker),
                        className: "flex-grow flex items-center justify-between px-4 py-2 rounded-xl bg-white/5 border border-white/10 text-xs font-bold text-slate-300 hover:bg-white/10 transition-all",
                        children: [
                          /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
                            /* @__PURE__ */ jsxDEV("img", { src: selectedModel.icon, className: "w-4 h-4 object-contain" }, void 0, false, {
                              fileName: "<stdin>",
                              lineNumber: 1919,
                              columnNumber: 29
                            }),
                            /* @__PURE__ */ jsxDEV("span", { children: selectedModel.name }, void 0, false, {
                              fileName: "<stdin>",
                              lineNumber: 1920,
                              columnNumber: 29
                            })
                          ] }, void 0, true, {
                            fileName: "<stdin>",
                            lineNumber: 1918,
                            columnNumber: 27
                          }),
                          /* @__PURE__ */ jsxDEV(ChevronDown, { size: 14 }, void 0, false, {
                            fileName: "<stdin>",
                            lineNumber: 1922,
                            columnNumber: 27
                          })
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "<stdin>",
                        lineNumber: 1914,
                        columnNumber: 25
                      }
                    ),
                    /* @__PURE__ */ jsxDEV(
                      "button",
                      {
                        onClick: () => setAiMode(aiMode === "code" ? "ask" : "code"),
                        className: `px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 border ${aiMode === "code" ? "bg-indigo-500/20 border-indigo-500 text-indigo-300" : "bg-amber-500/20 border-amber-500 text-amber-300"}`,
                        children: [
                          aiMode === "code" ? /* @__PURE__ */ jsxDEV(Zap, { size: 14 }, void 0, false, {
                            fileName: "<stdin>",
                            lineNumber: 1928,
                            columnNumber: 48
                          }) : /* @__PURE__ */ jsxDEV(MessageSquare, { size: 14 }, void 0, false, {
                            fileName: "<stdin>",
                            lineNumber: 1928,
                            columnNumber: 67
                          }),
                          aiMode.toUpperCase()
                        ]
                      },
                      void 0,
                      true,
                      {
                        fileName: "<stdin>",
                        lineNumber: 1924,
                        columnNumber: 25
                      }
                    )
                  ] }, void 0, true, {
                    fileName: "<stdin>",
                    lineNumber: 1913,
                    columnNumber: 23
                  }),
                  /* @__PURE__ */ jsxDEV(AnimatePresence, { children: showModelPicker && /* @__PURE__ */ jsxDEV(motion.div, { initial: { opacity: 0, y: 10 }, animate: { opacity: 1, y: 0 }, exit: { opacity: 0, y: 10 }, className: "bg-[#0f0f12] border border-white/10 rounded-xl p-1 grid grid-cols-2 gap-1 mb-1", children: MODELS.map((m) => /* @__PURE__ */ jsxDEV(
                    "div",
                    {
                      onClick: () => {
                        setSelectedModel(m);
                        setShowModelPicker(false);
                      },
                      className: `flex items-center gap-2 p-2 rounded-lg cursor-pointer transition-all ${selectedModel.id === m.id ? "bg-indigo-500/20 text-white" : "hover:bg-white/5 text-slate-400"}`,
                      children: [
                        /* @__PURE__ */ jsxDEV("img", { src: m.icon, className: "w-4 h-4 object-contain" }, void 0, false, {
                          fileName: "<stdin>",
                          lineNumber: 1942,
                          columnNumber: 33
                        }),
                        /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-bold truncate", children: m.name }, void 0, false, {
                          fileName: "<stdin>",
                          lineNumber: 1943,
                          columnNumber: 33
                        })
                      ]
                    },
                    m.id,
                    true,
                    {
                      fileName: "<stdin>",
                      lineNumber: 1937,
                      columnNumber: 31
                    }
                  )) }, void 0, false, {
                    fileName: "<stdin>",
                    lineNumber: 1935,
                    columnNumber: 27
                  }) }, void 0, false, {
                    fileName: "<stdin>",
                    lineNumber: 1933,
                    columnNumber: 23
                  }),
                  /* @__PURE__ */ jsxDEV("div", { className: "glass rounded-2xl p-1.5 flex gap-2 items-center shadow-2xl border-white/10", children: [
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        value: prompt,
                        onChange: (e) => setPrompt(e.target.value),
                        onKeyDown: (e) => {
                          if (e.key === "Enter") {
                            e.preventDefault();
                            e.stopPropagation();
                            handleModelAction();
                          }
                        },
                        placeholder: aiMode === "code" ? "Direct workspace edits..." : "Ask a question...",
                        className: "flex-grow bg-transparent border-none outline-none text-white text-sm font-medium placeholder:text-slate-600 px-3"
                      },
                      void 0,
                      false,
                      {
                        fileName: "<stdin>",
                        lineNumber: 1951,
                        columnNumber: 25
                      }
                    ),
                    /* @__PURE__ */ jsxDEV(
                      "button",
                      {
                        onClick: handleModelAction,
                        disabled: isGenerating,
                        className: `p-2.5 rounded-xl transition-all ${isGenerating ? "bg-slate-800 text-slate-600" : "bg-indigo-600 text-white hover:bg-indigo-500 shadow-lg shadow-indigo-600/20"}`,
                        children: isGenerating ? /* @__PURE__ */ jsxDEV(Loader2, { size: 18, className: "animate-spin" }, void 0, false, {
                          fileName: "<stdin>",
                          lineNumber: 1970,
                          columnNumber: 43
                        }) : /* @__PURE__ */ jsxDEV(Send, { size: 18 }, void 0, false, {
                          fileName: "<stdin>",
                          lineNumber: 1970,
                          columnNumber: 92
                        })
                      },
                      void 0,
                      false,
                      {
                        fileName: "<stdin>",
                        lineNumber: 1965,
                        columnNumber: 25
                      }
                    )
                  ] }, void 0, true, {
                    fileName: "<stdin>",
                    lineNumber: 1950,
                    columnNumber: 23
                  })
                ] }, void 0, true, {
                  fileName: "<stdin>",
                  lineNumber: 1912,
                  columnNumber: 21
                }) }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 1911,
                  columnNumber: 18
                })
              ] }, "chat", true, {
                fileName: "<stdin>",
                lineNumber: 1865,
                columnNumber: 15
              }),
              activeTab === "finenet" && /* @__PURE__ */ jsxDEV(motion.div, { initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 }, className: "h-full flex flex-col p-6 overflow-y-auto space-y-6 bg-slate-950/20", children: /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col gap-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between border-b border-white/5 pb-4", children: [
                  /* @__PURE__ */ jsxDEV("h4", { className: "text-sm font-black text-amber-400 tracking-widest uppercase flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxDEV(Cpu, { size: 18 }, void 0, false, {
                      fileName: "<stdin>",
                      lineNumber: 1983,
                      columnNumber: 23
                    }),
                    " FineNet & Cloud"
                  ] }, void 0, true, {
                    fileName: "<stdin>",
                    lineNumber: 1982,
                    columnNumber: 21
                  }),
                  /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] bg-green-500/10 text-green-500 px-2 py-0.5 rounded-full font-bold", children: "ALPHA" }, void 0, false, {
                    fileName: "<stdin>",
                    lineNumber: 1985,
                    columnNumber: 21
                  })
                ] }, void 0, true, {
                  fileName: "<stdin>",
                  lineNumber: 1981,
                  columnNumber: 19
                }),
                /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-amber-500/5 rounded-2xl border border-amber-500/20", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-amber-200 font-bold uppercase tracking-widest flex items-center gap-2", children: [
                      /* @__PURE__ */ jsxDEV(Globe, { size: 12 }, void 0, false, {
                        fileName: "<stdin>",
                        lineNumber: 1991,
                        columnNumber: 25
                      }),
                      " Cloud Shell Integration"
                    ] }, void 0, true, {
                      fileName: "<stdin>",
                      lineNumber: 1990,
                      columnNumber: 23
                    }),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-amber-200/60 mt-2 leading-relaxed", children: "Upcoming integration for Azure and Google Cloud Shell. Deploy your workspaces directly to scalable infrastructure with one click." }, void 0, false, {
                      fileName: "<stdin>",
                      lineNumber: 1993,
                      columnNumber: 23
                    })
                  ] }, void 0, true, {
                    fileName: "<stdin>",
                    lineNumber: 1989,
                    columnNumber: 21
                  }),
                  /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-white/5 rounded-2xl border border-white/5", children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-400 mb-2 font-bold uppercase tracking-widest", children: "Connected Developers" }, void 0, false, {
                      fileName: "<stdin>",
                      lineNumber: 1999,
                      columnNumber: 23
                    }),
                    /* @__PURE__ */ jsxDEV("div", { className: "flex flex-wrap gap-2", children: Object.values(room.peers).map((p, i) => /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2 bg-white/5 px-3 py-1.5 rounded-xl border border-white/10", children: [
                      /* @__PURE__ */ jsxDEV("img", { src: p.avatarUrl, className: "w-5 h-5 rounded-full" }, void 0, false, {
                        fileName: "<stdin>",
                        lineNumber: 2003,
                        columnNumber: 29
                      }),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-bold text-slate-300", children: p.username }, void 0, false, {
                        fileName: "<stdin>",
                        lineNumber: 2004,
                        columnNumber: 29
                      })
                    ] }, i, true, {
                      fileName: "<stdin>",
                      lineNumber: 2002,
                      columnNumber: 27
                    })) }, void 0, false, {
                      fileName: "<stdin>",
                      lineNumber: 2e3,
                      columnNumber: 23
                    })
                  ] }, void 0, true, {
                    fileName: "<stdin>",
                    lineNumber: 1998,
                    columnNumber: 21
                  }),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex-grow min-h-[200px] bg-black rounded-2xl p-4 font-mono text-[10px] text-emerald-400/80 overflow-y-auto border border-white/5", children: [
                    /* @__PURE__ */ jsxDEV("div", { children: "[SYSTEM] FineNet link established..." }, void 0, false, {
                      fileName: "<stdin>",
                      lineNumber: 2011,
                      columnNumber: 23
                    }),
                    /* @__PURE__ */ jsxDEV("div", { children: "[NET] Node: region-us-east-1" }, void 0, false, {
                      fileName: "<stdin>",
                      lineNumber: 2012,
                      columnNumber: 23
                    }),
                    /* @__PURE__ */ jsxDEV("div", { children: "[CLOUD] Preparing shell environments..." }, void 0, false, {
                      fileName: "<stdin>",
                      lineNumber: 2013,
                      columnNumber: 23
                    }),
                    /* @__PURE__ */ jsxDEV("div", { className: "animate-pulse", children: "_" }, void 0, false, {
                      fileName: "<stdin>",
                      lineNumber: 2014,
                      columnNumber: 23
                    })
                  ] }, void 0, true, {
                    fileName: "<stdin>",
                    lineNumber: 2010,
                    columnNumber: 21
                  })
                ] }, void 0, true, {
                  fileName: "<stdin>",
                  lineNumber: 1988,
                  columnNumber: 19
                })
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 1980,
                columnNumber: 17
              }) }, "finenet", false, {
                fileName: "<stdin>",
                lineNumber: 1979,
                columnNumber: 15
              }),
              activeTab === "extensions" && /* @__PURE__ */ jsxDEV(motion.div, { initial: { opacity: 0 }, animate: { opacity: 1 }, exit: { opacity: 0 }, className: "h-full flex flex-col p-6 overflow-y-auto space-y-6 bg-slate-950/20", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between border-b border-white/5 pb-4", children: [
                  /* @__PURE__ */ jsxDEV("h4", { className: "text-sm font-black text-emerald-400 tracking-widest uppercase flex items-center gap-2", children: [
                    /* @__PURE__ */ jsxDEV(Boxes, { size: 18 }, void 0, false, {
                      fileName: "<stdin>",
                      lineNumber: 2025,
                      columnNumber: 21
                    }),
                    " Extensions"
                  ] }, void 0, true, {
                    fileName: "<stdin>",
                    lineNumber: 2024,
                    columnNumber: 19
                  }),
                  /* @__PURE__ */ jsxDEV("button", { className: "text-[10px] font-bold text-slate-400 hover:text-white uppercase tracking-widest", children: "Browse Marketplace" }, void 0, false, {
                    fileName: "<stdin>",
                    lineNumber: 2027,
                    columnNumber: 19
                  })
                ] }, void 0, true, {
                  fileName: "<stdin>",
                  lineNumber: 2023,
                  columnNumber: 17
                }),
                /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-indigo-500/5 rounded-2xl border border-indigo-500/20 flex gap-4 items-start", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-indigo-500/20 rounded-xl text-indigo-400", children: /* @__PURE__ */ jsxDEV(Box, { size: 24 }, void 0, false, {
                      fileName: "<stdin>",
                      lineNumber: 2033,
                      columnNumber: 23
                    }) }, void 0, false, {
                      fileName: "<stdin>",
                      lineNumber: 2032,
                      columnNumber: 21
                    }),
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-bold text-white", children: "Advanced Icon Theme" }, void 0, false, {
                        fileName: "<stdin>",
                        lineNumber: 2036,
                        columnNumber: 23
                      }),
                      /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-slate-400 mt-1", children: "Automatically assigns professional icons to 30+ file types. (Enabled by Default)" }, void 0, false, {
                        fileName: "<stdin>",
                        lineNumber: 2037,
                        columnNumber: 23
                      })
                    ] }, void 0, true, {
                      fileName: "<stdin>",
                      lineNumber: 2035,
                      columnNumber: 21
                    })
                  ] }, void 0, true, {
                    fileName: "<stdin>",
                    lineNumber: 2031,
                    columnNumber: 19
                  }),
                  /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-white/5 rounded-2xl border border-white/10 opacity-50 grayscale flex gap-4 items-start", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "p-2 bg-white/10 rounded-xl text-slate-400", children: /* @__PURE__ */ jsxDEV(Zap, { size: 24 }, void 0, false, {
                      fileName: "<stdin>",
                      lineNumber: 2043,
                      columnNumber: 23
                    }) }, void 0, false, {
                      fileName: "<stdin>",
                      lineNumber: 2042,
                      columnNumber: 21
                    }),
                    /* @__PURE__ */ jsxDEV("div", { children: [
                      /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-bold text-white", children: "FineDebug Pro" }, void 0, false, {
                        fileName: "<stdin>",
                        lineNumber: 2046,
                        columnNumber: 23
                      }),
                      /* @__PURE__ */ jsxDEV("p", { className: "text-[11px] text-slate-400 mt-1", children: "Real-time debugger for React and Node.js environments. (Coming Soon)" }, void 0, false, {
                        fileName: "<stdin>",
                        lineNumber: 2047,
                        columnNumber: 23
                      })
                    ] }, void 0, true, {
                      fileName: "<stdin>",
                      lineNumber: 2045,
                      columnNumber: 21
                    })
                  ] }, void 0, true, {
                    fileName: "<stdin>",
                    lineNumber: 2041,
                    columnNumber: 19
                  }),
                  /* @__PURE__ */ jsxDEV("div", { className: "p-8 border-2 border-dashed border-white/5 rounded-3xl flex flex-col items-center justify-center text-center", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 bg-white/5 rounded-full flex items-center justify-center text-slate-600 mb-4", children: /* @__PURE__ */ jsxDEV(Plus, { size: 24 }, void 0, false, {
                      fileName: "<stdin>",
                      lineNumber: 2053,
                      columnNumber: 23
                    }) }, void 0, false, {
                      fileName: "<stdin>",
                      lineNumber: 2052,
                      columnNumber: 21
                    }),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs font-bold text-slate-500 uppercase tracking-widest", children: "Develop your own extension" }, void 0, false, {
                      fileName: "<stdin>",
                      lineNumber: 2055,
                      columnNumber: 21
                    })
                  ] }, void 0, true, {
                    fileName: "<stdin>",
                    lineNumber: 2051,
                    columnNumber: 19
                  })
                ] }, void 0, true, {
                  fileName: "<stdin>",
                  lineNumber: 2030,
                  columnNumber: 17
                })
              ] }, "extensions", true, {
                fileName: "<stdin>",
                lineNumber: 2022,
                columnNumber: 15
              })
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 1829,
              columnNumber: 11
            }),
            /* @__PURE__ */ jsxDEV(AnimatePresence, { children: showConsole && /* @__PURE__ */ jsxDEV(
              motion.div,
              {
                initial: { y: "100%" },
                animate: { y: 0 },
                exit: { y: "100%" },
                className: "absolute inset-0 bg-black/95 z-50 flex flex-col font-mono",
                children: [
                  /* @__PURE__ */ jsxDEV("div", { className: "p-4 border-b border-white/10 flex items-center justify-between", children: [
                    /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-3", children: [
                      /* @__PURE__ */ jsxDEV(Terminal, { size: 16, className: "text-indigo-500" }, void 0, false, {
                        fileName: "<stdin>",
                        lineNumber: 2071,
                        columnNumber: 21
                      }),
                      /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-black uppercase tracking-widest text-slate-400", children: "System Terminal" }, void 0, false, {
                        fileName: "<stdin>",
                        lineNumber: 2072,
                        columnNumber: 21
                      })
                    ] }, void 0, true, {
                      fileName: "<stdin>",
                      lineNumber: 2070,
                      columnNumber: 19
                    }),
                    /* @__PURE__ */ jsxDEV("div", { className: "flex gap-4", children: [
                      /* @__PURE__ */ jsxDEV("button", { onClick: () => setConsoleLogs2([]), className: "text-slate-600 hover:text-white transition-colors", children: /* @__PURE__ */ jsxDEV(Trash2, { size: 14 }, void 0, false, {
                        fileName: "<stdin>",
                        lineNumber: 2075,
                        columnNumber: 126
                      }) }, void 0, false, {
                        fileName: "<stdin>",
                        lineNumber: 2075,
                        columnNumber: 21
                      }),
                      /* @__PURE__ */ jsxDEV("button", { onClick: () => setShowConsole(false), className: "text-slate-600 hover:text-white transition-colors", children: /* @__PURE__ */ jsxDEV(X, { size: 16 }, void 0, false, {
                        fileName: "<stdin>",
                        lineNumber: 2076,
                        columnNumber: 129
                      }) }, void 0, false, {
                        fileName: "<stdin>",
                        lineNumber: 2076,
                        columnNumber: 21
                      })
                    ] }, void 0, true, {
                      fileName: "<stdin>",
                      lineNumber: 2074,
                      columnNumber: 19
                    })
                  ] }, void 0, true, {
                    fileName: "<stdin>",
                    lineNumber: 2069,
                    columnNumber: 17
                  }),
                  /* @__PURE__ */ jsxDEV("div", { className: "flex-grow overflow-y-auto p-5 text-[11px] space-y-2.5", children: [
                    consoleLogs.map((log, idx) => /* @__PURE__ */ jsxDEV("div", { className: `flex gap-3 items-start ${log.type === "error" ? "text-red-400" : "text-slate-400"}`, children: [
                      /* @__PURE__ */ jsxDEV("span", { className: "opacity-20 shrink-0", children: log.timestamp }, void 0, false, {
                        fileName: "<stdin>",
                        lineNumber: 2082,
                        columnNumber: 25
                      }),
                      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow prose prose-invert max-w-none prose-xs", dangerouslySetInnerHTML: {
                        __html: DOMPurify.sanitize(marked.parse(String(log.content)))
                      } }, void 0, false, {
                        fileName: "<stdin>",
                        lineNumber: 2083,
                        columnNumber: 25
                      })
                    ] }, idx, true, {
                      fileName: "<stdin>",
                      lineNumber: 2081,
                      columnNumber: 22
                    })),
                    consoleLogs.length === 0 && /* @__PURE__ */ jsxDEV("span", { className: "opacity-20 italic", children: "No output streams detected..." }, void 0, false, {
                      fileName: "<stdin>",
                      lineNumber: 2088,
                      columnNumber: 49
                    })
                  ] }, void 0, true, {
                    fileName: "<stdin>",
                    lineNumber: 2079,
                    columnNumber: 17
                  }),
                  /* @__PURE__ */ jsxDEV("div", { className: "p-4 bg-white/5 border-t border-white/5 flex gap-3", children: [
                    /* @__PURE__ */ jsxDEV(ChevronRight, { size: 14, className: "text-indigo-500 mt-0.5" }, void 0, false, {
                      fileName: "<stdin>",
                      lineNumber: 2091,
                      columnNumber: 19
                    }),
                    /* @__PURE__ */ jsxDEV(
                      "input",
                      {
                        className: "flex-grow bg-transparent outline-none text-xs text-indigo-300 placeholder:text-slate-700",
                        placeholder: "Execute JavaScript...",
                        value: terminalInput,
                        onChange: (e) => setTerminalInput(e.target.value),
                        onKeyDown: (e) => e.key === "Enter" && executeJS()
                      },
                      void 0,
                      false,
                      {
                        fileName: "<stdin>",
                        lineNumber: 2092,
                        columnNumber: 19
                      }
                    )
                  ] }, void 0, true, {
                    fileName: "<stdin>",
                    lineNumber: 2090,
                    columnNumber: 17
                  })
                ]
              },
              void 0,
              true,
              {
                fileName: "<stdin>",
                lineNumber: 2065,
                columnNumber: 15
              }
            ) }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 2063,
              columnNumber: 11
            }),
            /* @__PURE__ */ jsxDEV(AnimatePresence, { children: showPublishOptions && /* @__PURE__ */ jsxDEV(motion.div, { initial: { opacity: 0, y: 20 }, animate: { opacity: 1, y: 0 }, exit: { opacity: 0, y: 20 }, className: "absolute inset-0 z-60 flex items-center justify-center", children: /* @__PURE__ */ jsxDEV("div", { className: "w-[420px] bg-[#070708] border border-white/10 rounded-3xl p-6 glass shadow-xl", children: [
              /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-black mb-3", children: "Publish / Workspace Options" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 2109,
                columnNumber: 19
              }),
              /* @__PURE__ */ jsxDEV("div", { className: "space-y-4", children: [
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-bold", children: "Allow AI to modify files" }, void 0, false, {
                      fileName: "<stdin>",
                      lineNumber: 2113,
                      columnNumber: 25
                    }),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-400", children: "When enabled the AI can apply changes directly to your workspace." }, void 0, false, {
                      fileName: "<stdin>",
                      lineNumber: 2114,
                      columnNumber: 25
                    })
                  ] }, void 0, true, {
                    fileName: "<stdin>",
                    lineNumber: 2112,
                    columnNumber: 23
                  }),
                  /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("button", { onClick: () => setAllowAIEdit((a) => !a), className: `px-3 py-1 rounded-xl ${allowAIEdit ? "bg-indigo-500 text-white" : "bg-white/5 text-slate-300"}`, children: allowAIEdit ? "Enabled" : "Disabled" }, void 0, false, {
                    fileName: "<stdin>",
                    lineNumber: 2117,
                    columnNumber: 25
                  }) }, void 0, false, {
                    fileName: "<stdin>",
                    lineNumber: 2116,
                    columnNumber: 23
                  })
                ] }, void 0, true, {
                  fileName: "<stdin>",
                  lineNumber: 2111,
                  columnNumber: 21
                }),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-bold", children: "Allow AI to read workspace" }, void 0, false, {
                      fileName: "<stdin>",
                      lineNumber: 2123,
                      columnNumber: 25
                    }),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-400", children: "When enabled the AI will receive the full file contents and can inspect structure." }, void 0, false, {
                      fileName: "<stdin>",
                      lineNumber: 2124,
                      columnNumber: 25
                    })
                  ] }, void 0, true, {
                    fileName: "<stdin>",
                    lineNumber: 2122,
                    columnNumber: 23
                  }),
                  /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("button", { onClick: () => setAllowAIRead((r) => !r), className: `px-3 py-1 rounded-xl ${allowAIRead ? "bg-indigo-500 text-white" : "bg-white/5 text-slate-300"}`, children: allowAIRead ? "Enabled" : "Disabled" }, void 0, false, {
                    fileName: "<stdin>",
                    lineNumber: 2127,
                    columnNumber: 25
                  }) }, void 0, false, {
                    fileName: "<stdin>",
                    lineNumber: 2126,
                    columnNumber: 23
                  })
                ] }, void 0, true, {
                  fileName: "<stdin>",
                  lineNumber: 2121,
                  columnNumber: 21
                }),
                /* @__PURE__ */ jsxDEV("div", { className: "flex items-center justify-between", children: [
                  /* @__PURE__ */ jsxDEV("div", { children: [
                    /* @__PURE__ */ jsxDEV("p", { className: "text-sm font-bold", children: "Publish workspace" }, void 0, false, {
                      fileName: "<stdin>",
                      lineNumber: 2133,
                      columnNumber: 25
                    }),
                    /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-400", children: "Make this workspace visible to the community." }, void 0, false, {
                      fileName: "<stdin>",
                      lineNumber: 2134,
                      columnNumber: 25
                    })
                  ] }, void 0, true, {
                    fileName: "<stdin>",
                    lineNumber: 2132,
                    columnNumber: 23
                  }),
                  /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("button", { onClick: () => savePublishOptions({ allowAIEdit, published: !project?.published }), className: "px-4 py-2 rounded-2xl bg-amber-500 text-black font-bold", children: "Toggle Publish" }, void 0, false, {
                    fileName: "<stdin>",
                    lineNumber: 2137,
                    columnNumber: 25
                  }) }, void 0, false, {
                    fileName: "<stdin>",
                    lineNumber: 2136,
                    columnNumber: 23
                  })
                ] }, void 0, true, {
                  fileName: "<stdin>",
                  lineNumber: 2131,
                  columnNumber: 21
                }),
                /* @__PURE__ */ jsxDEV("div", { className: "flex justify-end gap-2", children: /* @__PURE__ */ jsxDEV("button", { onClick: () => setShowPublishOptions(false), className: "px-4 py-2 rounded-2xl bg-white/5", children: "Close" }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 2142,
                  columnNumber: 23
                }) }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 2141,
                  columnNumber: 21
                })
              ] }, void 0, true, {
                fileName: "<stdin>",
                lineNumber: 2110,
                columnNumber: 19
              })
            ] }, void 0, true, {
              fileName: "<stdin>",
              lineNumber: 2108,
              columnNumber: 17
            }) }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 2107,
              columnNumber: 15
            }) }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 2105,
              columnNumber: 11
            })
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 1828,
            columnNumber: 9
          })
        ]
      },
      void 0,
      true,
      {
        fileName: "<stdin>",
        lineNumber: 1817,
        columnNumber: 7
      }
    )
  ] }, void 0, true, {
    fileName: "<stdin>",
    lineNumber: 1616,
    columnNumber: 5
  });
};
async function callAI(model, prompt, currentFiles, activeFile, allowAIRead = true, mode = "code", images = []) {
  const fileStructure = Object.keys(currentFiles).join(", ");
  const isAsk = mode === "ask";
  const context = isAsk ? `You are a Senior Technical Consultant and Project Manager. 
Your task: Help the user plan, understand, and document their workspace. 
You are in ASK mode. Do NOT generate JSON or code updates. Just speak with the user.
Use Markdown to format your response (tables, bold, code blocks, etc.).

WORKSPACE STRUCTURE: [ ${fileStructure} ]
ACTIVE FILE: ${activeFile}` : `You are an elite Vibe Coder and Full Stack Architect. 
Your task: Modify the entire workspace according to the user's intent. You are NOT a chatbot; you are an Integrated Development Agent.

WORKSPACE STRUCTURE: [ ${fileStructure} ]
ACTIVE FILE: ${activeFile}

CURRENT FILE CONTENT:
${currentFiles[activeFile]}

STRATEGIC INSTRUCTIONS:
1. MANDATORY: You must return a JSON object if you need to change more than one file or create new files. 
   Format: {"files": {"path/to/file.js": "new content", "index.html": "..."}, "reasoning": "Detailed technical explanation of changes"}
2. If you only change the ACTIVE FILE and nothing else, you can return just the raw code (NO JSON, NO MARKDOWN).
3. SUPPORTED TECHNOLOGIES: React (via Babel), JSX, Tailwind CSS (via CDN), Lucide Icons, and standard Web APIs.
4. NO MARKDOWN for code: Never wrap your code response in \`\`\` blocks if you are returning raw code for a single file. 
5. CRITICAL: Be bold. Fix bugs, improve UI, and add requested features across all necessary files.`;
  let fullFilesSnapshot = Object.entries(currentFiles).map(([fname, fcontent]) => {
    return `--- ${fname} ---
${String(fcontent)}
`;
  }).join("\n");
  try {
    if (model.provider === "Groq") {
      const messages = [
        { role: "system", content: context },
        {
          role: "user",
          content: allowAIRead ? `${prompt}

WORKSPACE_SNAPSHOT:
${fullFilesSnapshot}` : prompt
        }
      ];
      if (images && images.length > 0) {
        messages[1].content = [
          { type: "text", text: messages[1].content },
          ...images.map((img) => ({ type: "image_url", image_url: { url: img } }))
        ];
      }
      const response = await fetch("https://api.groq.com/openai/v1/chat/completions", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${GROQ_API_KEY}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          model: model.url,
          messages,
          temperature: 0.4,
          max_tokens: 4096,
          top_p: 0.95
        })
      });
      if (!response.ok) throw new Error(`Groq Error: ${response.status}`);
      const data = await response.json();
      return data.choices?.[0]?.message?.content || "No response from Groq.";
    }
    if (model.provider === "Pollinations") {
      try {
        const payload = {
          model: model.url,
          messages: [
            { role: "system", content: context },
            { role: "user", content: allowAIRead ? `${prompt}

WORKSPACE_SNAPSHOT:
${fullFilesSnapshot}` : prompt }
          ],
          max_tokens: 2e3,
          temperature: 0.4
        };
        const resp = await fetch("https://api.pollinations.ai/v1/chat/completions", {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${POLLINATIONS_API_KEY}`,
            "Content-Type": "application/json"
          },
          body: JSON.stringify(payload)
        });
        if (!resp.ok) {
          const txt = await resp.text().catch(() => null);
          throw new Error(`Pollinations HTTP ${resp.status}: ${txt || resp.statusText}`);
        }
        const data = await resp.json();
        return data.choices?.[0]?.message?.content || data.message || data.content || JSON.stringify(data);
      } catch (err) {
        console.warn("Pollinations provider failed:", err);
        throw err;
      }
    }
    if (model.provider === "Websim") {
      const messages = [
        { role: "system", content: context },
        { role: "user", content: allowAIRead ? `${prompt}

WORKSPACE_SNAPSHOT:
${fullFilesSnapshot}` : prompt }
      ];
      const result = await window.websim.chat.completions.create({ messages });
      return result.content || result.choices?.[0]?.message?.content || String(result);
    }
    if (model.provider === "Hugging Face") {
      const hfFull = allowAIRead ? fullFilesSnapshot : `File list: ${Object.keys(currentFiles).join(", ")}`;
      const hfBody = {
        inputs: `${context}

User Prompt: ${prompt}

WORKSPACE CONTENTS:
${hfFull}

Optimized Solution:`,
        parameters: { max_new_tokens: 1500, return_full_text: false }
      };
      const response = await fetch(`https://api-inference.huggingface.co/models/${model.url}`, {
        method: "POST",
        headers: { "Authorization": `Bearer ${HF_API_KEY}`, "Content-Type": "application/json" },
        body: JSON.stringify(hfBody)
      });
      const data = await response.json();
      let text = Array.isArray(data) ? data[0].generated_text : data.generated_text || data.choices?.[0]?.text || data.error || "Error";
      if (text && text.includes("Optimized Solution:")) text = text.split("Optimized Solution:").pop();
      return String(text).trim();
    }
    if (model.provider === "OpenRouter") {
      let lastErr = null;
      for (let attempt = 0; attempt < OPENROUTER_API_KEYS.length; attempt++) {
        const key = getOpenRouterKey();
        try {
          const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
            method: "POST",
            headers: { "Authorization": `Bearer ${key}`, "Content-Type": "application/json" },
            body: JSON.stringify({
              model: model.url,
              messages: [{ role: "system", content: context }, { role: "user", content: allowAIRead ? `${prompt}

WORKSPACE_SNAPSHOT:
${fullFilesSnapshot}` : prompt }],
              max_tokens: 2e3
            })
          });
          if (!response.ok) {
            const text = await response.text().catch(() => null);
            lastErr = new Error(`OpenRouter HTTP ${response.status}: ${text || response.statusText}`);
            continue;
          }
          const data = await response.json();
          return data.choices?.[0]?.message?.content || data.choices?.[0]?.message?.content || "Model failure.";
        } catch (err) {
          lastErr = err;
          continue;
        }
      }
      throw lastErr || new Error("OpenRouter: all keys failed");
    }
    if (window?.websim?.chat?.completions?.create) {
      try {
        const result = await window.websim.chat.completions.create({
          messages: [{ role: "system", content: context }, { role: "user", content: allowAIRead ? `${prompt}

WORKSPACE_SNAPSHOT:
${fullFilesSnapshot}` : prompt }]
        });
        return result.content || result.choices?.[0]?.message?.content || String(result);
      } catch (wsErr) {
        console.warn("Websim fallback failed:", wsErr);
      }
    }
    return `ERROR: Unknown model provider "${model.provider}". Model must be one of: Websim, Hugging Face, OpenRouter.`;
  } catch (err) {
    console.error("AI Fallback triggered:", err);
    if (window?.websim?.chat?.completions?.create) {
      try {
        const result = await window.websim.chat.completions.create({
          messages: [{ role: "system", content: "SYSTEM FALLBACK. " + context }, { role: "user", content: prompt }]
        });
        return result.content || result.choices?.[0]?.message?.content || String(result);
      } catch (wsErr) {
        console.error("Websim final fallback failed:", wsErr);
      }
    }
    throw err;
  }
}
const HFRepoManager = {
  async listFiles(repoPath = "") {
    const url = `https://huggingface.co/api/datasets/${HF_DATASET_REPO}/tree/main/${repoPath}`;
    const resp = await fetch(url, { headers: { "Authorization": `Bearer ${HF_STORAGE_KEY}` } });
    if (!resp.ok) return [];
    return await resp.json();
  },
  // Custom Integration requested by user
  async uploadToHuggingFace(file) {
    try {
      if (!file) throw new Error("No file provided");
      if (window.websim && typeof window.websim.upload === "function") {
        const url = await window.websim.upload(file);
        try {
          const path = `uploads/${file.name}`;
          await HFRepoManager.uploadFile(path, await file.text());
        } catch (hfErr) {
          console.warn("HF dataset upload failed (non-fatal):", hfErr);
        }
        return { ok: true, url };
      }
      try {
        const path = `uploads/${file.name}`;
        const content = await file.text();
        const ok = await HFRepoManager.uploadFile(path, content);
        if (ok) {
          return { ok: true, url: `https://huggingface.co/datasets/${HF_DATASET_REPO}/resolve/main/${path}` };
        }
      } catch (e) {
        console.warn("Direct HF upload failed:", e);
      }
      return { ok: false, error: "No upload mechanism available" };
    } catch (err) {
      console.error("uploadToHuggingFace error:", err);
      return { ok: false, error: String(err) };
    }
  },
  async uploadToGitHub(file) {
    try {
      if (!file) throw new Error("No file provided");
      if (window.websim && typeof window.websim.upload === "function") {
        const url = await window.websim.upload(file);
        return { ok: true, url };
      }
      return { ok: false, error: "No client-side GitHub upload available" };
    } catch (err) {
      console.error("uploadToGitHub error:", err);
      return { ok: false, error: String(err) };
    }
  },
  async uploadFile(path, content) {
    const url = `https://huggingface.co/api/datasets/${HF_DATASET_REPO}/upload/main/${path}`;
    const blob = new Blob([content], { type: "text/plain" });
    const formData = new FormData();
    formData.append("file", blob, path.split("/").pop());
    const resp = await fetch(url, {
      method: "POST",
      headers: { "Authorization": `Bearer ${HF_STORAGE_KEY}` },
      body: formData
    });
    return resp.ok;
  },
  async createDataset(datasetId, options = {}) {
    const url = `https://huggingface.co/api/datasets`;
    const body = {
      id: datasetId,
      license: options.license || "apache-2.0",
      private: !!options.private,
      repo_type: "dataset",
      params: options.params || {}
    };
    const resp = await fetch(url, {
      method: "POST",
      headers: { "Authorization": `Bearer ${HF_STORAGE_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify(body)
    });
    if (!resp.ok) {
      const txt = await resp.text().catch(() => null);
      throw new Error(`Create dataset failed: ${resp.status} ${txt || resp.statusText}`);
    }
    return await resp.json();
  },
  async getStorageInfo() {
    const url = `https://huggingface.co/api/datasets/${HF_DATASET_REPO}`;
    try {
      const resp = await fetch(url, { headers: { "Authorization": `Bearer ${HF_STORAGE_KEY}` } });
      if (!resp.ok) return null;
      const data = await resp.json();
      return {
        sizeBytes: data?.size || data?.storage_size || null,
        filesCount: Array.isArray(data?.siblings) ? data.siblings.length : null,
        meta: data
      };
    } catch (e) {
      console.warn("Failed to fetch HF dataset metadata:", e);
      return null;
    }
  }
};
const RepoCard = ({ repo, onClick, user }) => /* @__PURE__ */ jsxDEV(
  motion.div,
  {
    whileHover: { y: -5 },
    onClick,
    className: "repo-card p-6 rounded-3xl cursor-pointer flex flex-col gap-4",
    children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between items-start", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "w-12 h-12 rounded-xl bg-emerald-500/10 flex items-center justify-center text-emerald-500", children: /* @__PURE__ */ jsxDEV(Boxes, { size: 24 }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 2483,
          columnNumber: 9
        }) }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 2482,
          columnNumber: 7
        }),
        /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: repo.username === user?.username && /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] bg-indigo-500/20 text-indigo-400 px-2 py-0.5 rounded-full font-bold", children: "OWNER" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 2486,
          columnNumber: 46
        }) }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 2485,
          columnNumber: 7
        })
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 2481,
        columnNumber: 5
      }),
      /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV("h3", { className: "text-lg font-black text-white", children: repo.name }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 2490,
          columnNumber: 7
        }),
        /* @__PURE__ */ jsxDEV("p", { className: "text-xs text-slate-400 line-clamp-2 mt-1", children: repo.description || "Hugging Face backed repository." }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 2491,
          columnNumber: 7
        })
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 2489,
        columnNumber: 5
      }),
      /* @__PURE__ */ jsxDEV("div", { className: "mt-auto flex items-center justify-between pt-4 border-t border-white/5", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-2", children: [
          /* @__PURE__ */ jsxDEV("img", { src: `https://images.websim.com/avatar/${repo.username}`, className: "w-5 h-5 rounded-full" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 2495,
            columnNumber: 9
          }),
          /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-bold text-slate-500", children: [
            "@",
            repo.username
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 2496,
            columnNumber: 9
          })
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 2494,
          columnNumber: 7
        }),
        /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-black text-emerald-500 uppercase tracking-tighter", children: "HF Cloud" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 2498,
          columnNumber: 7
        })
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 2493,
        columnNumber: 5
      })
    ]
  },
  void 0,
  true,
  {
    fileName: "<stdin>",
    lineNumber: 2476,
    columnNumber: 3
  }
);
const RepoExplorer = ({ repo, onBack, user }) => {
  const [files, setFiles] = useState([]);
  const [loading, setLoading] = useState(true);
  const [activeFile, setActiveFile] = useState(null);
  const [copilotThinking, setCopilotThinking] = useState(false);
  const [copilotResponse, setCopilotResponse] = useState("");
  const loadRepoFiles = async () => {
    setLoading(true);
    const list = await HFRepoManager.listFiles(repo.hf_path || "");
    setFiles(list);
    setLoading(false);
  };
  const handleFineCopilot = async () => {
    if (!activeFile || copilotThinking) return;
    setCopilotThinking(true);
    try {
      const analysis = await callAI(
        MODELS.find((m) => m.id === "gpt-oss-120b") || MODELS[0],
        `Analyze this file from repository ${repo.name}: ${activeFile.path}. Provide technical insights, potential optimizations, and logic summary.`,
        { [activeFile.path]: "Content fetching from HF Cloud..." },
        // Simulating repo file content context
        activeFile.path,
        true,
        "ask"
      );
      setCopilotResponse(analysis);
    } catch (e) {
      setCopilotResponse("Analysis failed: " + e.message);
    } finally {
      setCopilotThinking(false);
    }
  };
  const handleUpload = async () => {
    try {
      const input = document.createElement("input");
      input.type = "file";
      input.multiple = true;
      input.accept = "*/*";
      input.style.display = "none";
      document.body.appendChild(input);
      const pick = () => new Promise((resolve) => {
        input.onchange = () => resolve(Array.from(input.files || []));
        input.click();
      });
      const filesPicked = await pick();
      document.body.removeChild(input);
      if (!filesPicked || filesPicked.length === 0) return;
      for (const file of filesPicked) {
        setLoading(true);
        console.info(`[RepoExplorer] Uploading ${file.name} to HF...`, { time: (/* @__PURE__ */ new Date()).toLocaleTimeString() });
        const result = await HFRepoManager.uploadToHuggingFace(file);
        if (result && result.ok && result.url) {
          console.info(`[RepoExplorer] Uploaded ${file.name} -> ${result.url}`, { time: (/* @__PURE__ */ new Date()).toLocaleTimeString() });
        } else {
          console.warn(`[RepoExplorer] HF upload reported failure for ${file.name}: ${result && result.error}`, { time: (/* @__PURE__ */ new Date()).toLocaleTimeString() });
          if (window.websim && typeof window.websim.upload === "function") {
            try {
              const url = await window.websim.upload(file);
              console.info(`[RepoExplorer] Uploaded ${file.name} -> ${url} (websim)`, { time: (/* @__PURE__ */ new Date()).toLocaleTimeString() });
            } catch (e) {
              console.error(`[RepoExplorer] Fallback upload failed for ${file.name}:`, e);
            }
          }
        }
      }
      await loadRepoFiles();
    } catch (e) {
      console.error("Repo upload failed:", e);
      console.error(`[RepoExplorer] Repo upload failed: ${e && e.message ? e.message : e}`, { time: (/* @__PURE__ */ new Date()).toLocaleTimeString() });
      alert("Repository upload failed. See console for details.");
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    loadRepoFiles();
  }, [repo]);
  return /* @__PURE__ */ jsxDEV("div", { className: "h-full flex flex-col bg-[#050505] overflow-hidden", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "h-16 border-b border-white/5 flex items-center justify-between px-8 bg-[#0a0a0a]", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "flex items-center gap-4", children: [
        /* @__PURE__ */ jsxDEV("button", { onClick: onBack, className: "p-2 hover:bg-white/5 rounded-xl text-slate-500", children: /* @__PURE__ */ jsxDEV(ChevronDown, { className: "rotate-90", size: 20 }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 2594,
          columnNumber: 95
        }) }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 2594,
          columnNumber: 11
        }),
        /* @__PURE__ */ jsxDEV("div", { className: "flex flex-col", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-black text-emerald-500 uppercase tracking-widest", children: "Repository" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 2596,
            columnNumber: 13
          }),
          /* @__PURE__ */ jsxDEV("h1", { className: "text-lg font-black text-white", children: repo.name }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 2597,
            columnNumber: 13
          })
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 2595,
          columnNumber: 11
        })
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 2593,
        columnNumber: 9
      }),
      /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [
        /* @__PURE__ */ jsxDEV("button", { onClick: loadRepoFiles, className: "p-2 hover:bg-white/5 rounded-xl text-slate-400", title: "Refresh", children: /* @__PURE__ */ jsxDEV(History, { size: 18 }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 2601,
          columnNumber: 118
        }) }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 2601,
          columnNumber: 11
        }),
        /* @__PURE__ */ jsxDEV(
          "button",
          {
            onClick: handleFineCopilot,
            className: `px-5 py-2 ${copilotThinking ? "bg-emerald-500/50" : "bg-emerald-500"} text-white rounded-xl text-xs font-black shadow-lg shadow-emerald-500/20 flex items-center gap-2`,
            children: [
              copilotThinking ? /* @__PURE__ */ jsxDEV(Loader2, { size: 14, className: "animate-spin" }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 2606,
                columnNumber: 32
              }) : /* @__PURE__ */ jsxDEV(Sparkles, { size: 14 }, void 0, false, {
                fileName: "<stdin>",
                lineNumber: 2606,
                columnNumber: 81
              }),
              "FINE COPILOT"
            ]
          },
          void 0,
          true,
          {
            fileName: "<stdin>",
            lineNumber: 2602,
            columnNumber: 11
          }
        )
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 2600,
        columnNumber: 9
      })
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 2592,
      columnNumber: 7
    }),
    /* @__PURE__ */ jsxDEV("div", { className: "flex-grow flex overflow-hidden", children: [
      /* @__PURE__ */ jsxDEV("div", { className: "w-80 border-r border-white/5 flex flex-col bg-black/20", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "p-4 flex items-center justify-between border-b border-white/5", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-[10px] font-black text-slate-500 uppercase", children: "Explorer" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 2615,
            columnNumber: 13
          }),
          /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: [
            /* @__PURE__ */ jsxDEV("button", { onClick: handleUpload, title: "Upload to HF/GitHub", className: "p-1.5 hover:bg-emerald-500/10 rounded-lg text-emerald-500 transition-colors", children: /* @__PURE__ */ jsxDEV(Plus, { size: 16 }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 2618,
              columnNumber: 17
            }) }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 2617,
              columnNumber: 15
            }),
            /* @__PURE__ */ jsxDEV(
              "button",
              {
                onClick: async () => {
                  try {
                    const JSZip = (await import("https://esm.sh/jszip@3.10.0")).default;
                    const zip = new JSZip();
                    zip.file("README.md", `# ${repo.name}
Generated archive.`);
                    const content = await zip.generateAsync({ type: "blob" });
                    const file = new File([content], "archive.zip", { type: "application/zip" });
                    await HFRepoManager.uploadToHuggingFace(file);
                    loadRepoFiles();
                  } catch (e) {
                    console.error(e);
                  }
                },
                title: "Archive current repo to Zip",
                className: "p-1.5 hover:bg-emerald-500/10 rounded-lg text-emerald-500 transition-colors",
                children: /* @__PURE__ */ jsxDEV(Download, { size: 16 }, void 0, false, {
                  fileName: "<stdin>",
                  lineNumber: 2635,
                  columnNumber: 17
                })
              },
              void 0,
              false,
              {
                fileName: "<stdin>",
                lineNumber: 2620,
                columnNumber: 15
              }
            )
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 2616,
            columnNumber: 13
          })
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 2614,
          columnNumber: 11
        }),
        /* @__PURE__ */ jsxDEV("div", { className: "flex-grow overflow-y-auto p-2", children: loading ? /* @__PURE__ */ jsxDEV("div", { className: "p-8 text-center text-slate-600 animate-pulse", children: "Syncing HF..." }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 2641,
          columnNumber: 15
        }) : files.map((f, i) => /* @__PURE__ */ jsxDEV("div", { onClick: () => setActiveFile(f), className: "flex items-center gap-3 px-4 py-2 rounded-xl hover:bg-white/5 cursor-pointer text-slate-400", children: [
          /* @__PURE__ */ jsxDEV(FileCode, { size: 16, className: "text-emerald-500/60" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 2645,
            columnNumber: 19
          }),
          /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-bold truncate flex-grow", children: f.path }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 2646,
            columnNumber: 19
          })
        ] }, i, true, {
          fileName: "<stdin>",
          lineNumber: 2644,
          columnNumber: 17
        })) }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 2639,
          columnNumber: 11
        }),
        /* @__PURE__ */ jsxDEV("div", { className: "p-4 border-t border-white/5 bg-emerald-500/5", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "flex justify-between text-[10px] font-bold mb-1", children: [
            /* @__PURE__ */ jsxDEV("span", { className: "text-emerald-400", children: "HF STORAGE" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 2653,
              columnNumber: 15
            }),
            /* @__PURE__ */ jsxDEV("span", { className: "text-slate-500", children: "0.2 / 3.0 GB" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 2654,
              columnNumber: 15
            })
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 2652,
            columnNumber: 13
          }),
          /* @__PURE__ */ jsxDEV("div", { className: "h-1 bg-white/5 rounded-full overflow-hidden", children: /* @__PURE__ */ jsxDEV("div", { className: "h-full bg-emerald-500 w-[7%]" }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 2656,
            columnNumber: 74
          }) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 2656,
            columnNumber: 13
          })
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 2651,
          columnNumber: 11
        })
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 2613,
        columnNumber: 9
      }),
      /* @__PURE__ */ jsxDEV("div", { className: "flex-grow flex flex-col bg-[#080808]", children: activeFile ? /* @__PURE__ */ jsxDEV("div", { className: "flex-grow flex flex-col", children: [
        /* @__PURE__ */ jsxDEV("div", { className: "p-4 border-b border-white/5 flex items-center justify-between bg-black/40", children: [
          /* @__PURE__ */ jsxDEV("span", { className: "text-xs font-mono text-emerald-400", children: activeFile.path }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 2663,
            columnNumber: 17
          }),
          /* @__PURE__ */ jsxDEV("div", { className: "flex gap-2", children: /* @__PURE__ */ jsxDEV("button", { className: "p-2 text-slate-400", children: /* @__PURE__ */ jsxDEV(Edit3, { size: 16 }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 2664,
            columnNumber: 84
          }) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 2664,
            columnNumber: 45
          }) }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 2664,
            columnNumber: 17
          })
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 2662,
          columnNumber: 15
        }),
        /* @__PURE__ */ jsxDEV("div", { className: "flex-grow p-8 font-mono text-sm text-slate-300 overflow-y-auto bg-black/60", children: /* @__PURE__ */ jsxDEV("div", { className: "prose prose-invert prose-emerald max-w-none", children: [
          /* @__PURE__ */ jsxDEV("h4", { className: "text-emerald-400 mb-4 flex items-center gap-2", children: [
            /* @__PURE__ */ jsxDEV(Sparkles, { size: 16 }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 2669,
              columnNumber: 21
            }),
            " File Intelligence"
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 2668,
            columnNumber: 19
          }),
          copilotThinking ? /* @__PURE__ */ jsxDEV("div", { className: "animate-pulse space-y-4", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "h-4 bg-white/5 rounded w-3/4" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 2673,
              columnNumber: 23
            }),
            /* @__PURE__ */ jsxDEV("div", { className: "h-4 bg-white/5 rounded w-full" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 2674,
              columnNumber: 23
            }),
            /* @__PURE__ */ jsxDEV("div", { className: "h-4 bg-white/5 rounded w-5/6" }, void 0, false, {
              fileName: "<stdin>",
              lineNumber: 2675,
              columnNumber: 23
            })
          ] }, void 0, true, {
            fileName: "<stdin>",
            lineNumber: 2672,
            columnNumber: 21
          }) : /* @__PURE__ */ jsxDEV("div", { dangerouslySetInnerHTML: { __html: marked.parse(copilotResponse || `Select a file and click **FINE COPILOT** to generate a deep-dive analysis and optimization report using FineTunes AI.`) } }, void 0, false, {
            fileName: "<stdin>",
            lineNumber: 2678,
            columnNumber: 21
          })
        ] }, void 0, true, {
          fileName: "<stdin>",
          lineNumber: 2667,
          columnNumber: 17
        }) }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 2666,
          columnNumber: 15
        })
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 2661,
        columnNumber: 13
      }) : /* @__PURE__ */ jsxDEV("div", { className: "flex-grow flex flex-col items-center justify-center opacity-40", children: [
        /* @__PURE__ */ jsxDEV(Boxes, { size: 48, className: "text-emerald-500 mb-6" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 2685,
          columnNumber: 15
        }),
        /* @__PURE__ */ jsxDEV("h2", { className: "text-xl font-black text-white", children: "Repository Browser" }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 2686,
          columnNumber: 15
        }),
        /* @__PURE__ */ jsxDEV("p", { className: "text-sm", children: "Select a file to begin." }, void 0, false, {
          fileName: "<stdin>",
          lineNumber: 2687,
          columnNumber: 15
        })
      ] }, void 0, true, {
        fileName: "<stdin>",
        lineNumber: 2684,
        columnNumber: 13
      }) }, void 0, false, {
        fileName: "<stdin>",
        lineNumber: 2659,
        columnNumber: 9
      })
    ] }, void 0, true, {
      fileName: "<stdin>",
      lineNumber: 2612,
      columnNumber: 7
    })
  ] }, void 0, true, {
    fileName: "<stdin>",
    lineNumber: 2591,
    columnNumber: 5
  });
};
createRoot(document.getElementById("root")).render(/* @__PURE__ */ jsxDEV(App, {}, void 0, false, {
  fileName: "<stdin>",
  lineNumber: 2696,
  columnNumber: 52
}));
